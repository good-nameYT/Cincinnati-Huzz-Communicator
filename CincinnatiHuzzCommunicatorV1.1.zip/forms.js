// Inflected French words: reads Wiktionary's "plural of" / "inflection of" markers,
// names the conjugation, and builds the matching English form ("chats" -> cats,
// "mangeons" -> we eat, "mangions" -> we were eating, "mangé" -> eaten).
(() => {
  /* ---------- reading Wiktionary ---------- */
  const TPL_TAGS = {
    'plural of': ['p'], 'pl of': ['p'],
    'feminine of': ['f'], 'feminine singular of': ['f', 's'], 'female equivalent of': ['f'],
    'feminine plural of': ['f', 'p'], 'masculine plural of': ['m', 'p'], 'masculine of': ['m'],
    'past participle of': ['past', 'part'], 'fr-past participle of': ['past', 'part'], 'past participle form of': ['past', 'part'],
    'present participle of': ['pres', 'part']
  };
  const INFL = /^(inflection of|infl of|inflected form of)$/;

  function parseTemplateLine(line) {
    const out = [];
    for (const m of line.matchAll(/\{\{([^{}]+)\}\}/g)) {
      const parts = m[1].split('|').map(x => x.trim());
      const name = parts.shift().toLowerCase();
      if (!INFL.test(name) && !TPL_TAGS[name]) continue;
      const named = {}, pos = [];
      parts.forEach(p => { const k = p.match(/^([\w-]+)=(.*)$/); if (k) named[k[1]] = k[2]; else pos.push(p); });
      let lemma, tags;
      if (pos[0] === 'fr') { lemma = pos[1]; tags = pos.slice(3); }
      else if (named.lang === 'fr' || !named.lang) { lemma = pos[0]; tags = pos.slice(2); }
      if (!lemma) continue;
      if (TPL_TAGS[name]) { out.push({ lemma, sets: [TPL_TAGS[name].slice()] }); continue; }
      const sets = [[]];
      tags.forEach(t => { if (t === ';') sets.push([]); else if (t) sets[sets.length - 1].push(t); });
      out.push({ lemma, sets: sets.filter(s => s.length) });
    }
    return out;
  }

  // French section wikitext -> [{pos, lemma, sets}]
  function parseForms(section) {
    if (!section) return [];
    const out = [];
    let pos = '';
    for (const line of section.split('\n')) {
      const h = line.match(/^=+\s*(.+?)\s*=+\s*$/);
      if (h) { pos = h[1]; continue; }
      if (!/^#\s/.test(line)) continue;
      parseTemplateLine(line).forEach(f => out.push({ pos, ...f }));
    }
    return out;
  }

  // Wiktionary REST definitions -> same shape. defs: [{pos, top, items}]
  const TEXT_TAGS = [
    [/\bfirst\b/, '1'], [/\bsecond\b/, '2'], [/\bthird\b/, '3'],
    [/\bsingular\b/, 's'], [/\bplural\b/, 'p'], [/\bmasculine\b/, 'm'], [/\bfeminine\b/, 'f'],
    [/\bpast historic\b/, 'phis'], [/\bimperfect\b/, 'impf'], [/\bfuture\b/, 'fut'], [/\bconditional\b/, 'cond'],
    [/\bsubjunctive\b/, 'sub'], [/\bindicative\b/, 'indc'], [/\bimperative\b/, 'impr'], [/\bparticiple\b/, 'part']
  ];
  function tagsFromText(str) {
    str = str.toLowerCase();
    const tags = [];
    const persons = TEXT_TAGS.slice(0, 3).filter(([r]) => r.test(str)).map(([, t]) => t);
    if (persons.length) tags.push(persons.join('//'));
    TEXT_TAGS.slice(3).forEach(([r, t]) => { if (r.test(str)) tags.push(t); });
    if (/\bpresent\b/.test(str)) tags.push('pres');
    if (/\bpast participle\b/.test(str)) tags.push('past');
    return tags;
  }
  function parseFormsFromRest(defs) {
    const out = [];
    for (const d of defs || []) {
      const top = (d.top || '').replace(/\s+/g, ' ').trim();
      let m = top.match(/^(?:\([^)]*\)\s*)*(?:inflection|inflected form) of ([\p{L}'’\- ]+?)\s*:?\s*$/iu);
      if (m && d.items && d.items.length) { out.push({ pos: d.pos, lemma: m[1].trim(), sets: d.items.map(tagsFromText).filter(s => s.length) }); continue; }
      m = top.match(/^(?:\([^)]*\)\s*)*([\w/ -]*?(?:person|singular|plural|masculine|feminine|participle|indicative|subjunctive|imperative|conditional|future|imperfect|historic)[\w/ -]*?) of ([\p{L}'’\-]+(?: [\p{L}'’\-]+)?)\s*[.:;]?$/iu);
      if (m) out.push({ pos: d.pos, lemma: m[2].trim(), sets: [tagsFromText(m[1])] });
    }
    return out;
  }

  /* ---------- naming the form ---------- */
  const DIM = {
    person: { '1': 1, '2': 2, '3': 3, 'first-person': 1, 'second-person': 2, 'third-person': 3 },
    number: { s: 's', sg: 's', singular: 's', p: 'p', pl: 'p', plural: 'p' },
    gender: { m: 'm', f: 'f', masculine: 'm', feminine: 'f' },
    tense: { pres: 'pres', present: 'pres', impf: 'impf', imperfect: 'impf', fut: 'fut', future: 'fut', cond: 'cond', conditional: 'cond',
      phis: 'phis', 'past historic': 'phis', pret: 'phis', preterite: 'phis', past: 'past', simple_past: 'phis' },
    mood: { indc: 'indc', ind: 'indc', indicative: 'indc', sub: 'sub', subj: 'sub', subjunctive: 'sub', impr: 'impr', imp: 'impr', imperative: 'impr',
      part: 'part', ptcp: 'part', participle: 'part', inf: 'inf', infinitive: 'inf' }
  };
  function expand(set) {
    let readings = [{}];
    for (const raw of set) {
      const alts = String(raw).toLowerCase().split('//').map(x => x.trim()).filter(Boolean);
      let dim = null; const vals = [];
      for (const a of alts) {
        for (const d in DIM) if (a in DIM[d]) { dim = dim || d; if (d === dim) vals.push(DIM[d][a]); break; }
      }
      if (!dim || !vals.length) continue;
      readings = readings.flatMap(r => vals.map(v => ({ ...r, [dim]: v })));
    }
    return readings;
  }

  function kindOf(form) {
    const all = form.sets.flat().join(' ').toLowerCase();
    if (/\bpart\b|participle|ptcp/.test(all)) return /\bpres\b|present/.test(all) && !/\bpast\b/.test(all) ? 'prespart' : 'pastpart';
    if (/\b(pres|impf|fut|cond|phis|indc|sub|subj|impr|inf)\b|indicative|subjunctive|imperative|conditional|future|imperfect|[123](\/\/|$)/.test(all)) return 'verb';
    if (/^(adjective|participle)$/i.test(form.pos || '')) return 'adj';
    if (/\bp\b|\bpl\b|plural/.test(all)) return 'plural';
    if (/\bf\b|feminine|\bm\b|masculine/.test(all)) return 'gender';
    return 'other';
  }

  function moodLabel(r) {
    if (r.mood === 'part') return r.tense === 'pres' ? 'present participle' : 'past participle';
    if (r.mood === 'inf') return 'infinitive';
    if (r.mood === 'impr') return 'imperative';
    const t = { pres: 'present', impf: 'imperfect', fut: 'future', cond: 'conditional', phis: 'past historic', past: 'past' }[r.tense] || '';
    if (r.mood === 'sub') return (t || 'present') + ' subjunctive';
    if (r.tense === 'fut' || r.tense === 'cond' || r.tense === 'phis') return t;
    return (t || 'present') + ' indicative';
  }
  const ORD = { 1: '1st', 2: '2nd', 3: '3rd' };
  function personLabel(r) {
    if (!r.person) return r.number ? (r.number === 's' ? 'singular' : 'plural') : '';
    return ORD[r.person] + ' person ' + (r.number === 'p' ? 'plural' : 'singular');
  }

  /* ---------- English ---------- */
  const IRREG = {};
  ('arise arose arisen|awake awoke awoken|bear bore borne|beat beat beaten|become became become|begin began begun|bend bent bent|bet bet bet|bind bound bound|' +
   'bite bit bitten|bleed bled bled|blow blew blown|break broke broken|breed bred bred|bring brought brought|build built built|burn burned burned|burst burst burst|' +
   'buy bought bought|catch caught caught|choose chose chosen|cling clung clung|come came come|cost cost cost|creep crept crept|cut cut cut|deal dealt dealt|' +
   'dig dug dug|do did done|draw drew drawn|dream dreamed dreamed|drink drank drunk|drive drove driven|eat ate eaten|fall fell fallen|feed fed fed|feel felt felt|' +
   'fight fought fought|find found found|flee fled fled|fly flew flown|forbid forbade forbidden|forget forgot forgotten|forgive forgave forgiven|freeze froze frozen|' +
   'get got gotten|give gave given|go went gone|grind ground ground|grow grew grown|hang hung hung|have had had|hear heard heard|hide hid hidden|hit hit hit|' +
   'hold held held|hurt hurt hurt|keep kept kept|kneel knelt knelt|know knew known|lay laid laid|lead led led|lean leaned leaned|leap leapt leapt|learn learned learned|' +
   'leave left left|lend lent lent|let let let|lie lay lain|light lit lit|lose lost lost|make made made|mean meant meant|meet met met|mistake mistook mistaken|' +
   'overcome overcame overcome|pay paid paid|prove proved proven|put put put|quit quit quit|read read read|rid rid rid|ride rode ridden|ring rang rung|rise rose risen|' +
   'run ran run|say said said|see saw seen|seek sought sought|sell sold sold|send sent sent|set set set|sew sewed sewn|shake shook shaken|shed shed shed|' +
   'shine shone shone|shoot shot shot|show showed shown|shrink shrank shrunk|shut shut shut|sing sang sung|sink sank sunk|sit sat sat|sleep slept slept|' +
   'slide slid slid|sling slung slung|speak spoke spoken|speed sped sped|spend spent spent|spin spun spun|spit spat spat|split split split|spread spread spread|' +
   'spring sprang sprung|stand stood stood|steal stole stolen|stick stuck stuck|sting stung stung|stink stank stunk|strike struck struck|string strung strung|' +
   'strive strove striven|swear swore sworn|sweep swept swept|swim swam swum|swing swung swung|take took taken|teach taught taught|tear tore torn|tell told told|' +
   'think thought thought|throw threw thrown|tread trod trodden|understand understood understood|undertake undertook undertaken|undo undid undone|' +
   'upset upset upset|wake woke woken|wear wore worn|weave wove woven|weep wept wept|win won won|wind wound wound|withdraw withdrew withdrawn|wring wrung wrung|' +
   'write wrote written|can could could|may might might|shall should should|will would would|must had_to had_to|forecast forecast forecast|' +
   'foresee foresaw foreseen|undergo underwent undergone|withstand withstood withstood|behold beheld beheld|lie_down lay_down lain_down')
    .split('|').forEach(e => { const [b, p, pp] = e.split(' '); IRREG[b.replace(/_/g, ' ')] = [p.replace(/_/g, ' '), pp.replace(/_/g, ' ')]; });

  const VOW = /[aeiou]/;
  function doubles(w) {   // stop -> stopp-, but not "open", "visit", "eat"
    return w.length <= 4 && /^[^aeiou]*[aeiou][bdgklmnprt]$/.test(w) && !/(w|x|y)$/.test(w);
  }
  function s3(w) {
    if (w === 'have') return 'has';
    if (w === 'do') return 'does';
    if (w === 'go') return 'goes';
    if (/(s|x|z|ch|sh|o)$/.test(w)) return w + 'es';
    if (/[^aeiou]y$/.test(w)) return w.slice(0, -1) + 'ies';
    return w + 's';
  }
  function ed(w) {
    if (IRREG[w]) return IRREG[w][0];
    if (/e$/.test(w)) return w + 'd';
    if (/[^aeiou]y$/.test(w)) return w.slice(0, -1) + 'ied';
    if (doubles(w)) return w + w.slice(-1) + 'ed';
    return w + 'ed';
  }
  function pp(w) {
    if (IRREG[w]) return IRREG[w][1];
    return ed(w);
  }
  function ing(w) {
    if (/ie$/.test(w)) return w.slice(0, -2) + 'ying';
    if (/[^aeiouy]e$/.test(w) && w !== 'be') return w.slice(0, -1) + 'ing';
    if (doubles(w)) return w + w.slice(-1) + 'ing';
    return w + 'ing';
  }

  // "to wake up" -> {head:"wake", tail:" up"}
  function verbParts(gloss) {
    let g = gloss.trim().replace(/^to\s+/i, '');
    const m = g.match(/^(\S+)(.*)$/);
    return m ? { head: m[1].toLowerCase(), tail: m[2] } : null;
  }

  const PRON = { '1s': 'I', '2s': 'you', '3s': 'he/she', '1p': 'we', '2p': 'you', '3p': 'they' };
  function englishFor(r, gloss) {
    const v = verbParts(gloss);
    if (!v) return '';
    const { head, tail } = v;
    const key = (r.person || 3) + (r.number || 's');
    const pron = PRON[key] || 'he/she';
    const third = key === '3s';
    const isBe = head === 'be';
    const pastBe = (key === '1s' || key === '3s') ? 'was' : 'were';
    const lab = moodLabel(r);
    let out;
    if (lab === 'past participle') out = (isBe ? 'been' : pp(head)) + tail;
    else if (lab === 'present participle') out = ing(head) + tail;
    else if (lab === 'infinitive') out = 'to ' + head + tail;
    else if (lab === 'imperative') out = (key === '1p' ? 'let’s ' : '') + head + tail + '!';
    else if (lab === 'present indicative') out = pron + ' ' + (isBe ? (key === '1s' ? 'am' : third ? 'is' : 'are') : third ? s3(head) : head) + tail;
    else if (lab === 'imperfect indicative') out = pron + ' ' + (isBe ? pastBe : pastBe + ' ' + ing(head)) + tail;
    else if (lab === 'future') out = pron + ' will ' + head + tail;
    else if (lab === 'conditional') out = pron + ' would ' + head + tail;
    else if (lab === 'past historic' || lab === 'past indicative') out = pron + ' ' + (isBe ? pastBe : ed(head)) + tail;
    else if (lab === 'present subjunctive') out = 'that ' + pron + ' ' + head + tail;
    else if (lab === 'imperfect subjunctive') out = 'that ' + pron + ' ' + (isBe ? 'were' : ed(head)) + tail;
    else out = '';
    return out;
  }

  const PL_IRREG = { man: 'men', woman: 'women', child: 'children', person: 'people', mouse: 'mice', foot: 'feet', tooth: 'teeth', goose: 'geese',
    ox: 'oxen', louse: 'lice', die: 'dice', knife: 'knives', life: 'lives', wife: 'wives', leaf: 'leaves', half: 'halves', wolf: 'wolves',
    shelf: 'shelves', thief: 'thieves', loaf: 'loaves', calf: 'calves', elf: 'elves', self: 'selves', potato: 'potatoes', tomato: 'tomatoes',
    hero: 'heroes', echo: 'echoes', cactus: 'cacti', crisis: 'crises', analysis: 'analyses', phenomenon: 'phenomena', criterion: 'criteria' };
  const PL_SAME = new Set('sheep fish deer series species aircraft moose salmon trout offspring news information advice furniture luggage equipment rice money hair music homework weather'.split(' '));
  function pluralWord(w) {
    const lw = w.toLowerCase();
    if (PL_SAME.has(lw)) return w;
    if (PL_IRREG[lw]) return PL_IRREG[lw];
    if (/(s|x|z|ch|sh)$/.test(lw)) return w + 'es';
    if (/[^aeiou]y$/.test(lw)) return w.slice(0, -1) + 'ies';
    return w + 's';
  }
  // "piece of cake" -> "pieces of cake", "police officer" -> "police officers", "a cat" -> "cats"
  function pluralize(gloss) {
    let g = gloss.trim().replace(/^(a|an|the)\s+/i, '');
    const of = g.match(/^(.+?)(\s+(?:of|in|on|for|with|from|to)\s+.*)$/);
    const head = of ? of[1] : g, rest = of ? of[2] : '';
    const words = head.split(' ');
    words[words.length - 1] = pluralWord(words[words.length - 1]);
    return words.join(' ') + rest;
  }

  // Readable English gloss from a definition's text
  function cleanGloss(t) {
    let g = (t || '').replace(/\s+/g, ' ').trim();
    for (let i = 0; i < 4; i++) g = g.replace(/^\([^()]*\)\s*/, '');
    g = g.replace(/\s*\([^()]*\)/g, '').replace(/\s*\[[^\]]*\]/g, '');
    g = g.split(/[;:]/)[0].trim();
    g = g.replace(/[.。]+$/, '').trim();
    return g;
  }
  const FORM_TEXT = /^(?:\([^)]*\)\s*)*(?:(?:first|second|third)(?:\/(?:first|second|third))*[-\s]person|(?:masculine|feminine)(?:\s+(?:singular|plural))?|plural|singular|inflection|inflected form|past participle|present participle|form|alternative form|elision)\b[^]*?\bof\b/i;
  function isFormText(t) { return FORM_TEXT.test((t || '').trim()); }

  // Turn one word's forms + its lemma's glosses into what the card shows.
  // lemmaInfo: {pos, glosses:[...]} for the lemma.
  function describe(form, lemmaInfo) {
    const kind = kindOf(form);
    const glosses = (lemmaInfo && lemmaInfo.glosses) || [];
    const lemmaPos = (lemmaInfo && lemmaInfo.pos) || '';
    const res = { kind, lemma: form.lemma, lemmaGloss: glosses[0] || '', rows: [], english: '' };
    if (kind === 'plural' || kind === 'gender' || kind === 'adj') {
      const tags = form.sets.flat().map(t => String(t).toLowerCase());
      const fem = tags.some(t => t === 'f' || t === 'feminine'), masc = tags.some(t => t === 'm' || t === 'masculine');
      const pl = tags.some(t => t === 'p' || t === 'pl' || t === 'plural');
      const nounish = kind === 'plural' && !/adjective|participle/i.test(lemmaPos) && !/adjective/i.test(form.pos || '');
      res.label = [fem ? 'feminine' : masc ? 'masculine' : '', pl ? 'plural' : (fem || masc) ? 'singular' : ''].filter(Boolean).join(' ') || 'form';
      res.english = glosses.length ? glosses.slice(0, 2).map(g => (pl && nounish ? pluralize(g) : g)).join(', ') : '';
      res.pos = nounish ? 'noun' : 'adjective';
      return res;
    }
    if (kind === 'verb' || kind === 'pastpart' || kind === 'prespart') {
      const gloss = glosses.find(g => /^to\s/i.test(g)) || glosses[0] || '';
      const readings = form.sets.flatMap(expand);
      if (kind !== 'verb' && !readings.some(r => r.mood === 'part')) readings.push({ mood: 'part', tense: kind === 'prespart' ? 'pres' : 'past' });
      const groups = new Map();
      for (const r of readings) {
        if (!r.mood && !r.tense && !r.person) continue;
        if (kind !== 'verb' && r.mood !== 'part') continue;
        const lab = moodLabel(r);
        if (!groups.has(lab)) groups.set(lab, []);
        const g = groups.get(lab);
        if (!g.some(x => x.person === r.person && x.number === r.number)) g.push(r);
      }
      for (const [lab, rs] of groups) {
        rs.sort((a, b) => (a.number === b.number ? 0 : a.number === 's' ? -1 : 1) || (a.person || 0) - (b.person || 0));
        const byNum = new Map();
        rs.forEach(r => { if (!r.person) return; const k = r.number === 'p' ? 'plural' : 'singular'; if (!byNum.has(k)) byNum.set(k, []); byNum.get(k).push(ORD[r.person]); });
        const persons = [...byNum].map(([n, ps]) => ps.join(' & ') + ' person ' + n);
        const eng = gloss ? [...new Set(rs.map(r => englishFor(r, gloss)).filter(Boolean))] : [];
        const gender = rs.find(r => r.gender || r.number) && lab.includes('participle')
          ? [rs[0].gender === 'f' ? 'feminine' : rs[0].gender === 'm' ? 'masculine' : '', rs[0].number === 'p' ? 'plural' : rs[0].number === 's' ? 'singular' : ''].filter(Boolean).join(' ')
          : '';
        res.rows.push({ label: lab.charAt(0).toUpperCase() + lab.slice(1), who: lab.includes('participle') ? gender : persons.join(', '), english: eng.join(' · ') });
      }
      res.english = res.rows.length ? res.rows[0].english : '';
      res.infinitiveGloss = gloss ? (/^to\s/i.test(gloss) ? gloss : 'to ' + gloss) : '';
      res.pos = 'verb';
      return res;
    }
    res.english = glosses[0] || '';
    return res;
  }

  globalThis.MotForms = { parseForms, parseFormsFromRest, describe, kindOf, cleanGloss, isFormText, pluralize, englishFor, expand };
})();
