// Fetches dictionary pages for the content script, shares captured subtitle tracks
// with every frame of the same tab, and keeps the per-episode word history for quizzes.
const ALLOW = [
  /^https:\/\/en\.wiktionary\.org\//,
  /^https:\/\/api\.mymemory\.translated\.net\//,
  /^https:\/\/([\w-]+\.)*crunchyroll\.com\//
];

// "netflix:81234567" or "crunchyroll:GXXXXXX" from a watch page URL
function epKey(url) {
  const m = (url || '').match(/^https:\/\/(?:[\w-]+\.)*(netflix|crunchyroll)\.com\/(?:[\w-]+\/)?watch\/([\w-]+)/i);
  if (!m) return null;
  const site = m[1].toLowerCase();
  return { key: site + ':' + m[2], site: site === 'netflix' ? 'Netflix' : 'Crunchyroll' };
}
function cleanTitle(t, site) {
  t = (t || '').replace(/\s*[|\-–]\s*(Netflix|Crunchyroll).*$/i, '').replace(/^Watch\s+/i, '').trim();
  return /^(netflix|crunchyroll)?$/i.test(t) ? '' : t;
}

let chain = Promise.resolve();
function record(tab, msg) {
  chain = chain.then(async () => {
    const k = epKey(tab && tab.url);
    if (!k) return;
    const { episodes } = await chrome.storage.local.get({ episodes: {} });
    const ep = episodes[k.key] || { key: k.key, site: k.site, title: '', url: tab.url, clicked: [], seen: {}, created: Date.now() };
    if (msg.title) ep.title = msg.title;
    else if (!ep.title) ep.title = cleanTitle(tab.title, k.site);
    ep.url = tab.url;
    let newClick = false;
    for (const c of msg.clicked || []) {
      if (!c || !c.w) continue;
      const i = ep.clicked.findIndex(x => x.w.toLowerCase() === c.w.toLowerCase());
      if (i >= 0) { if (c.gloss) ep.clicked[i].gloss = c.gloss; }
      else { ep.clicked.push({ w: c.w, gloss: c.gloss || '', line: c.line || '', at: Date.now() }); newClick = true; }
    }
    let size = Object.keys(ep.seen).length;
    for (const s of msg.seen || []) {
      if (!s || !s.w) continue;
      const e = ep.seen[s.w];
      if (e) e.n++;
      else if (size < 900) { ep.seen[s.w] = { n: 1, line: s.line || '' }; size++; }
    }
    if (newClick && ep.quiz) ep.quiz.stale = true;
    ep.updated = Date.now();
    episodes[k.key] = ep;
    Object.keys(episodes).sort((a, b) => episodes[b].updated - episodes[a].updated).slice(30).forEach(x => delete episodes[x]);
    await chrome.storage.local.set({ episodes });
  }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!msg) return;
  if (msg.type === 'get') {
    if (!ALLOW.some(r => r.test(msg.url))) { send({ ok: false, status: 0 }); return; }
    fetch(msg.url, { headers: { 'Api-User-Agent': 'CincinnatiHuzzCommunicator/1.4 (Chrome extension)' } })
      .then(async r => send({ ok: r.ok, status: r.status, text: await r.text() }))
      .catch(() => send({ ok: false, status: 0 }));
    return true;
  }
  if (msg.type === 'track' && sender.tab) {
    chrome.tabs.sendMessage(sender.tab.id, { type: 'track', track: msg.track }).catch(() => {});
  }
  if (msg.type === 'ep' && sender.tab) record(sender.tab, msg);
  if (msg.type === 'openQuiz' && sender.tab) {
    const k = epKey(sender.tab.url);
    chain.then(() => chrome.tabs.create({
      url: chrome.runtime.getURL('quiz.html' + (k ? '?ep=' + encodeURIComponent(k.key) : '')),
      index: sender.tab.index + 1
    }));
  }
});
