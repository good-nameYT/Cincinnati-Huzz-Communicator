// Common French expressions, matched in subtitles before single words.
// {avoir}, {être}, etc. match any common form of that verb, so "{avoir} besoin de"
// catches "j'ai besoin de", "tu as besoin d'aide", "on avait besoin de"...
// {se} matches the reflexive pronouns me/m'/te/t'/se/s'.
(() => {
  const WORD_RE = /[\p{L}\p{M}]+(?:['’\-][\p{L}\p{M}]+)*/gu;
  const ELISION_RE = /^(l|d|j|m|n|s|t|c|qu|jusqu|lorsqu|puisqu|quoiqu)['’]/iu;
  const norm = s => s.toLowerCase().replace(/’/g, "'");

  function tokenize(text) {
    const out = [];
    let last = 0;
    const word = t => ({ t, word: true, norm: norm(t) });
    for (const m of text.matchAll(WORD_RE)) {
      if (m.index > last) out.push({ t: text.slice(last, m.index), word: false });
      let w = m[0];
      const e = w.match(ELISION_RE);
      if (e && w.length > e[0].length) { out.push(word(e[0])); w = w.slice(e[0].length); }
      out.push(word(w));
      last = m.index + m[0].length;
    }
    if (last < text.length) out.push({ t: text.slice(last), word: false });
    return out;
  }

  const set = s => new Set(s.split(' '));
  const SETS = {
    'avoir': set("ai as a avons avez ont avais avait avions aviez avaient aurai auras aura aurons aurez auront aurais aurait aurions auriez auraient aie aies ait ayons ayez aient eu eue eus avoir ayant"),
    'être': set("suis es est sommes êtes sont étais était étions étiez étaient serai seras sera serons serez seront serais serait serions seriez seraient sois soit soyons soyez soient été être étant"),
    'faire': set("fais fait faisons faites font faisais faisait faisions faisiez faisaient ferai feras fera ferons ferez feront ferais ferait ferions feriez feraient fasse fasses fassions fassiez fassent faire faisant"),
    'aller': set("vais vas va allons allez vont allais allait allions alliez allaient irai iras ira irons irez iront irais irait irions iriez iraient aille ailles aillent aller allé allée allés allées"),
    'venir': set("viens vient venons venez viennent venais venait venions veniez venaient viendrai viendras viendra viendrons viendrez viendront viendrais viendrait vienne viennes venir venu venue venus venues"),
    'se': set("me m' te t' se s'")
  };
  const PREFIX = {
    'rendre': 'rend', 'occuper': 'occup', 'souvenir': 'souv', 'moquer': 'moqu', 'tromper': 'tromp',
    'dépêcher': 'dépêch', 'débrouiller': 'débrouill', 'passer': 'pass', 'inquiéter': 'inqui', 'casser': 'cass'
  };
  const ELIDE = { le: "l'", la: "l'", de: "d'", je: "j'", me: "m'", te: "t'", se: "s'", ne: "n'", ce: "c'", que: "qu'", jusque: "jusqu'", si: "s'" };

  // [pattern, English meaning, optional note]
  const LIST = [
    ['{être} en train de', 'be in the middle of doing something; be ...ing right now', 'Je suis en train de manger = I’m eating (right now). It stresses that the action is happening at this moment.'],
    ['en train de', 'in the middle of (doing); ...ing right now', 'Usually after être: il est en train de dormir = he’s sleeping right now.'],
    ['il y a', 'there is, there are; with a time, ago', 'Il y a deux ans = two years ago.'],
    ["il n'y a pas", 'there isn’t, there aren’t'],
    ['il y a pas', 'there isn’t, there aren’t (casual, the ne is dropped)'],
    ['y a', 'there is, there are (very casual form of il y a)'],
    ["qu'est-ce que", 'what (asking about the object)', 'Qu’est-ce que tu fais ? = What are you doing?'],
    ["qu'est-ce qui", 'what (as the subject)', 'Qu’est-ce qui t’arrive ? = What’s happening to you?'],
    ["qu'est-ce qui se passe", 'what’s going on? what’s happening?'],
    ["qu'est-ce qu'il y a", 'what’s wrong? what is it?'],
    ["qu'est-ce que c'est", 'what is it? what’s that?'],
    ['est-ce que', 'turns a statement into a yes or no question', 'There’s no English word for it. Est-ce que tu viens ? = Are you coming?'],
    ["c'est-à-dire", 'that is to say, I mean'],
    ["c'est ça", 'that’s it, that’s right'],
    ["c'est pas vrai", 'no way! you’re kidding!'],
    ["ce n'est pas vrai", 'no way! that can’t be true'],
    ["ce n'est pas grave", 'it’s no big deal, it doesn’t matter'],
    ["c'est pas grave", 'it’s no big deal, never mind (casual)'],
    ['pas grave', 'no big deal'],
    ['tout à fait', 'absolutely, exactly, quite'],
    ['tout de suite', 'right away, immediately'],
    ['tout le monde', 'everyone, everybody'],
    ["tout à l'heure", 'a little while ago, or in a little while'],
    ["à tout à l'heure", 'see you later (today)'],
    ['tout le temps', 'all the time'],
    ['tout de même', 'still, all the same, even so'],
    ['tout va bien', 'everything’s fine'],
    ['pas du tout', 'not at all'],
    ['du coup', 'so, as a result', 'A very common filler in casual speech, a lot like “so” in English.'],
    ['en fait', 'actually, in fact'],
    ['au fait', 'by the way'],
    ['par contre', 'on the other hand, however'],
    ['quand même', 'still, anyway, even so; also adds emphasis', 'C’est quand même bizarre = It’s really pretty weird.'],
    ['bien sûr', 'of course'],
    ["d'accord", 'okay, all right; agreed'],
    ["{être} d'accord", 'agree; (c’est d’accord) that’s fine'],
    ['ça va', 'how’s it going? / I’m fine, it’s fine'],
    ['ça marche', 'sounds good, okay (literally “that works”)'],
    ['ça vaut le coup', 'it’s worth it'],
    ['ça fait longtemps', 'it’s been a long time'],
    ['ça ne fait rien', 'never mind, it doesn’t matter'],
    ['ça dépend', 'it depends'],
    ['ça suffit', 'that’s enough'],
    ['il faut', 'it’s necessary; (I, you, we) have to, must', 'Il faut partir = We have to leave. Who has to do it comes from context.'],
    ['il vaut mieux', 'it’s better to, you’d better'],
    ['il paraît que', 'apparently, they say that'],
    ['{être} sur le point de', 'be about to'],
    ['{venir} de', 'have just (done something)', 'Only when a verb follows: je viens de manger = I just ate. Before a place it means “come from”.'],
    ['{avoir} besoin de', 'need'],
    ['{avoir} envie de', 'feel like, want to'],
    ['{avoir} peur de', 'be afraid of'],
    ['{avoir} peur', 'be scared, be afraid'],
    ["{avoir} l'air", 'seem, look (like)', 'Tu as l’air fatigué = You look tired.'],
    ["{avoir} l'habitude de", 'be used to, usually do'],
    ['{avoir} raison', 'be right'],
    ['{avoir} tort', 'be wrong'],
    ['{avoir} faim', 'be hungry'],
    ['{avoir} soif', 'be thirsty'],
    ['{avoir} sommeil', 'be sleepy'],
    ['{avoir} chaud', 'be hot (feel hot)'],
    ['{avoir} froid', 'be cold (feel cold)'],
    ['{avoir} du mal à', 'have trouble (doing something)'],
    ['{avoir} mal', 'be in pain, hurt', 'J’ai mal à la tête = I have a headache.'],
    ['{avoir} lieu', 'take place, happen'],
    ['{avoir} hâte de', 'can’t wait to, look forward to'],
    ['{avoir} de la chance', 'be lucky'],
    ['{avoir} honte', 'be ashamed, be embarrassed'],
    ['{avoir} le temps', 'have time'],
    ['en {avoir} marre', 'be fed up, have had enough', 'J’en ai marre = I’m sick of it.'],
    ['en {avoir} assez', 'have had enough'],
    ['{faire} attention', 'pay attention, be careful, watch out'],
    ['{faire} semblant de', 'pretend to'],
    ['{faire} exprès', 'do on purpose'],
    ['{faire} la queue', 'wait in line'],
    ['{faire} gaffe', 'be careful, watch out (slang)'],
    ['{faire} confiance', 'trust'],
    ['{faire} peur', 'scare, frighten'],
    ['{faire} mal', 'hurt (someone or something)'],
    ['{faire} la fête', 'party, celebrate'],
    ['{faire} la gueule', 'sulk, be in a mood (slang)'],
    ['{être} en retard', 'be late'],
    ['{être} en avance', 'be early'],
    ['{être} en colère', 'be angry'],
    ['{aller} bien', 'be well, be fine'],
    ['{se} {rendre} compte', 'realize', null, 'se rendre compte'],
    ['{se} en {aller}', 'leave, go away', 'Je m’en vais = I’m leaving.', "s'en aller"],
    ['{se} {occuper} de', 'take care of, deal with, look after', null, "s'occuper de"],
    ['{se} {souvenir} de', 'remember', null, 'se souvenir de'],
    ['{se} {moquer} de', 'make fun of; not care about', 'Je m’en moque = I don’t care.', 'se moquer de'],
    ['{se} {tromper}', 'be wrong, make a mistake', null, 'se tromper'],
    ['{se} {dépêcher}', 'hurry', null, 'se dépêcher'],
    ['{se} {débrouiller}', 'manage, get by, figure it out', null, 'se débrouiller'],
    ['{se} {inquiéter}', 'worry', null, "s'inquiéter"],
    ['{se} {casser}', 'leave, get out of here (slang); break', null, 'se casser'],
    ['{se} {passer}', 'happen; (se passer de) do without', null, 'se passer'],
    ["n'importe quoi", 'anything; nonsense', 'Dis pas n’importe quoi = Don’t talk nonsense.'],
    ["n'importe qui", 'anyone'],
    ["n'importe où", 'anywhere'],
    ["n'importe quand", 'anytime'],
    ['à cause de', 'because of'],
    ['grâce à', 'thanks to'],
    ['au lieu de', 'instead of'],
    ['à part', 'apart from, except'],
    ['à peu près', 'about, roughly'],
    ['au moins', 'at least'],
    ['de toute façon', 'anyway, in any case'],
    ['en tout cas', 'in any case, anyway'],
    ['à la fois', 'at the same time, both'],
    ['de temps en temps', 'from time to time'],
    ['en même temps', 'at the same time; then again'],
    ['à mon avis', 'in my opinion'],
    ['il était une fois', 'once upon a time'],
    ['parce que', 'because'],
    ['alors que', 'while, whereas'],
    ['bien que', 'although'],
    ['dès que', 'as soon as'],
    ['pendant que', 'while'],
    ['avant de', 'before (doing something)'],
    ["jusqu'à", 'until, up to, as far as'],
    ['près de', 'near, close to'],
    ['loin de', 'far from'],
    ['à côté de', 'next to, beside'],
    ['en face de', 'opposite, across from'],
    ['par exemple', 'for example'],
    ['en effet', 'indeed, that’s right'],
    ['de rien', 'you’re welcome'],
    ["s'il te plaît", 'please (to a friend)'],
    ["s'il vous plaît", 'please (polite or to several people)'],
    ['à bientôt', 'see you soon'],
    ['pas mal', 'not bad; (pas mal de) quite a lot of'],
    ['pas encore', 'not yet'],
    ['plus jamais', 'never again'],
    ['en plus', 'besides, on top of that'],
    ['tant pis', 'too bad, oh well'],
    ['tant mieux', 'so much the better, good'],
    ['à vrai dire', 'to tell the truth'],
    ['laisse tomber', 'forget it, drop it'],
    ['on y va', 'let’s go'],
    ['comment ça', 'what do you mean? how so?'],
    ["quoi qu'il en soit", 'anyway, be that as it may'],
    ['de plus en plus', 'more and more'],
    ['de moins en moins', 'less and less'],
    ['au cas où', 'just in case']
  ];

  function patTokens(p) {
    const out = [];
    for (const piece of p.split(' ')) {
      const b = piece.match(/^\{(.+)\}$/);
      if (b) out.push({ set: b[1] });
      else tokenize(piece).filter(t => t.word).forEach(t => out.push({ lit: t.norm }));
    }
    return out;
  }
  function canonOf(p) {
    return p.replace(/\{(.+?)\}/g, '$1')
      .replace(/\b(le|la|de|je|me|te|se|ne|ce|que) (?=[aeiouyhéèêàâîôû])/gi, (m, w) => ELIDE[w.toLowerCase()]);
  }
  const ENTRIES = LIST.map(([p, g, n, c]) => {
    const pat = patTokens(p);
    const canon = c || canonOf(p);
    return { pat, gloss: g, note: n || '', canon, wk: canon };
  }).sort((a, b) => b.pat.length - a.pat.length);

  function tokMatch(pt, tok) {
    if (pt.set) {
      if (SETS[pt.set]) return SETS[pt.set].has(tok);
      if (PREFIX[pt.set]) return tok.startsWith(PREFIX[pt.set]);
      return false;
    }
    return tok === pt.lit || ELIDE[pt.lit] === tok;
  }

  // words: array of normalized word strings. Returns [{start, end, entry}] (end exclusive).
  function findBuiltin(words) {
    const out = [];
    const used = new Array(words.length).fill(false);
    for (const entry of ENTRIES) {
      const n = entry.pat.length;
      for (let i = 0; i + n <= words.length; i++) {
        let ok = true;
        for (let k = 0; k < n; k++) { if (used[i + k] || !tokMatch(entry.pat[k], words[i + k])) { ok = false; break; } }
        if (ok) { out.push({ start: i, end: i + n, entry }); for (let k = i; k < i + n; k++) used[k] = true; }
      }
    }
    return out.sort((a, b) => a.start - b.start);
  }

  const STOP = set("le la les l' un une des de d' du à au aux en y et ou il elle on je j' tu nous vous ils elles ce c' ça que qu' qui ne n' pas se s' me m' te t' est a son sa ses mon ma mes ton ta tes leur leurs lui");

  globalThis.MotAMot = { tokenize, findBuiltin, STOP, norm };
})();
