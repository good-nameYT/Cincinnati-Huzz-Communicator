// Episode quiz: 10 words, starting with the ones clicked during the episode,
// topped up with random words that appeared in its subtitles.
const $ = id => document.getElementById(id);
const QUIZ_LEN = 10;
const show = id => ['loading', 'pick', 'quiz', 'done'].forEach(x => { $(x).hidden = x !== id; });
const shuffle = a => { a = [...a]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const decode = s => new DOMParser().parseFromString(s, 'text/html').documentElement.textContent;
const sameish = (a, b) => a.trim().toLowerCase() === b.trim().toLowerCase();

let key = new URLSearchParams(location.search).get('ep');
let ep = null, questions = [], at = 0, results = [];

/* ---------- meanings ---------- */
function tidy(g, w) {
  g = decode(g || '').replace(/\s+/g, ' ').trim().replace(/[.。]+$/, '');
  if (g.length > 1 && g === g.toUpperCase() && /[A-Z]/.test(g)) g = g.toLowerCase();
  if (/^[A-ZÀ-Ý][a-zà-ÿ]/.test(g) && w === w.toLowerCase()) g = g.charAt(0).toLowerCase() + g.slice(1);
  return g.length > 70 ? g.slice(0, 67).replace(/\s\S*$/, '') + '…' : g;
}
async function glossFor(w) {
  try {
    const r = await fetch('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(w) + '&langpair=fr|en');
    const t = (await r.json()).responseData.translatedText;
    if (t && !/MYMEMORY WARNING|INVALID|QUERY LENGTH/i.test(t)) { const g = tidy(t, w); if (g && !sameish(g, w)) return g; }
  } catch (_) {}
  try {
    const r = await fetch('https://en.wiktionary.org/api/rest_v1/page/definition/' + encodeURIComponent(w.replace(/ /g, '_')));
    if (r.ok) {
      const fr = (await r.json()).fr || [];
      for (const p of fr) for (const d of p.definitions || []) {
        const doc = new DOMParser().parseFromString(d.definition || '', 'text/html');
        doc.querySelectorAll('ul,ol,dl,sup').forEach(n => n.remove());
        const g = tidy(doc.body.textContent, w);
        if (g) return g;
      }
    }
  } catch (_) {}
  return '';
}

/* ---------- building the 10 words ---------- */
async function buildItems() {
  const items = [], used = new Set();
  const add = it => { items.push(it); used.add(it.w.toLowerCase()); };
  const status = n => { $('loadingText').textContent = 'Getting your quiz ready… ' + n + ' of ' + QUIZ_LEN + ' words'; };

  // 1. words you clicked (a random 10 if you clicked more than that)
  const clicked = shuffle(ep.clicked || []);
  for (const c of clicked) {
    if (items.length >= QUIZ_LEN) break;
    if (used.has(c.w.toLowerCase())) continue;
    let g = tidy(c.gloss, c.w);
    if (!g || sameish(g, c.w)) g = await glossFor(c.w);
    if (!g) continue;
    add({ w: c.w, gloss: g, line: c.line || '', src: 'clicked' });
    status(items.length);
  }

  // 2. random words from the episode's subtitles
  const pool = shuffle(Object.entries(ep.seen || {}).filter(([w]) => !used.has(w))).slice(0, 40);
  for (let i = 0; i < pool.length && items.length < QUIZ_LEN; i += 4) {
    const batch = pool.slice(i, i + Math.min(4, QUIZ_LEN - items.length + 1));
    const gl = await Promise.all(batch.map(([w]) => glossFor(w)));
    batch.forEach(([w, info], k) => {
      if (items.length >= QUIZ_LEN || !gl[k] || used.has(w)) return;
      add({ w, gloss: gl[k], line: info.line || '', src: 'episode' });
    });
    status(items.length);
  }
  return items;
}

function makeQuestions(items) {
  return items.map((it, i) => {
    const type = i % 3 === 2 ? 'en2fr' : 'fr2en';
    const field = type === 'fr2en' ? 'gloss' : 'w';
    const answer = it[field];
    const opts = [answer];
    for (const o of shuffle(items)) {
      if (opts.length >= 4) break;
      if (!opts.some(x => sameish(x, o[field]))) opts.push(o[field]);
    }
    return { it, type, answer, options: shuffle(opts) };
  });
}

/* ---------- screens ---------- */
function speak(text) {
  if (!('speechSynthesis' in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = 'fr-FR'; u.rate = 0.9;
  const v = speechSynthesis.getVoices().find(v => /^fr/i.test(v.lang));
  if (v) u.voice = v;
  speechSynthesis.speak(u);
}

function lineWith(line, word, blank) {
  const p = $('qLine');
  p.textContent = '';
  if (!line) { p.hidden = true; return; }
  p.hidden = false;
  const i = line.toLowerCase().replace(/’/g, "'").indexOf(word.toLowerCase());
  if (i < 0) { if (blank) { p.hidden = true; return; } p.textContent = line; return; }
  p.append(line.slice(0, i));
  const m = document.createElement(blank ? 'span' : 'mark');
  if (blank) m.className = 'blank';
  m.textContent = line.slice(i, i + word.length);
  p.append(m, line.slice(i + word.length));
}

function renderQuestion() {
  const q = questions[at];
  $('count').textContent = (at + 1) + ' / ' + questions.length;
  $('barFill').style.width = (at / questions.length * 100) + '%';
  $('feedback').textContent = ''; $('feedback').className = 'feedback';
  $('next').hidden = true;
  const word = $('qWord');
  if (q.type === 'fr2en') {
    $('qType').textContent = 'What does this mean?';
    word.textContent = q.it.w; word.className = ''; word.lang = 'fr';
    $('say').hidden = false;
    lineWith(q.it.line, q.it.w, false);
  } else {
    $('qType').textContent = 'Which French word or phrase means this?';
    word.textContent = q.it.gloss; word.className = 'en'; word.lang = 'en';
    $('say').hidden = true;
    lineWith(q.it.line, q.it.w, true);
  }
  $('qSrc').textContent = q.it.src === 'clicked' ? 'You clicked this one' : 'From the episode';
  const box = $('opts');
  box.textContent = '';
  q.options.forEach((o, i) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'opt';
    if (q.type === 'en2fr') b.lang = 'fr';
    const k = document.createElement('span'); k.className = 'k'; k.textContent = i + 1;
    const t = document.createElement('span'); t.textContent = o;
    b.append(k, t);
    b.addEventListener('click', () => answer(i));
    box.append(b);
  });
  box.querySelector('.opt').focus({ preventScroll: true });
}

function answer(i) {
  const q = questions[at];
  if (results[at] !== undefined) return;
  const btns = [...$('opts').children];
  const right = sameish(q.options[i], q.answer);
  results[at] = right;
  btns.forEach((b, j) => {
    b.disabled = true;
    if (sameish(q.options[j], q.answer)) b.classList.add('right');
    else if (j === i) b.classList.add('wrong');
  });
  const fb = $('feedback');
  fb.className = 'feedback ' + (right ? 'good' : 'bad');
  fb.textContent = right ? 'Correct.' : 'Not quite. ' + q.it.w + ' means “' + q.it.gloss + '”.';
  if (q.type === 'en2fr') lineWith(q.it.line, q.it.w, false);
  $('next').hidden = false;
  $('next').textContent = at + 1 < questions.length ? 'Next' : 'See results';
  $('next').focus({ preventScroll: true });
}

async function finish() {
  show('done');
  const score = results.filter(Boolean).length;
  $('scoreBig').textContent = score + ' / ' + questions.length;
  const prevBest = ep.quiz && typeof ep.quiz.best === 'number' ? ep.quiz.best : null;
  $('scoreNote').textContent = prevBest !== null && score > prevBest ? 'New best for this episode.' :
    prevBest !== null ? 'Best so far: ' + prevBest + ' / ' + questions.length : '';
  const ul = $('review');
  ul.textContent = '';
  questions.forEach((q, i) => {
    const li = document.createElement('li');
    const m = document.createElement('span'); m.className = 'mark ' + (results[i] ? 'good' : 'bad'); m.textContent = results[i] ? '✓' : '✗';
    const d = document.createElement('div');
    const w = document.createElement('span'); w.className = 'w'; w.lang = 'fr'; w.textContent = q.it.w;
    const g = document.createElement('span'); g.className = 'g'; g.textContent = ' · ' + q.it.gloss;
    d.append(w, g);
    if (q.it.line) { const l = document.createElement('div'); l.className = 'l'; l.lang = 'fr'; l.textContent = q.it.line; d.append(l); }
    li.append(m, d);
    ul.append(li);
  });
  $('saveMissed').hidden = results.every(Boolean);
  $('saveMissed').disabled = false; $('saveMissed').textContent = 'Save missed words';

  const { episodes } = await chrome.storage.local.get({ episodes: {} });
  const cur = episodes[key];
  if (cur && cur.quiz) {
    cur.quiz.best = Math.max(score, cur.quiz.best || 0);
    cur.quiz.last = score;
    cur.quiz.taken = (cur.quiz.taken || 0) + 1;
    await chrome.storage.local.set({ episodes });
    ep = cur;
  }
}

function start() {
  questions = makeQuestions(ep.quiz.items);
  at = 0; results = [];
  show('quiz');
  renderQuestion();
}

async function prepare(fresh) {
  show('loading');
  const { episodes } = await chrome.storage.local.get({ episodes: {} });
  ep = episodes[key];
  if (!ep.quiz || ep.quiz.stale || fresh || ep.quiz.items.length < QUIZ_LEN) {
    const items = await buildItems();
    if (items.length < 4) {
      $('loadingText').textContent = items.length
        ? 'Only ' + items.length + ' words from this episode so far. Watch a little more and try again.'
        : 'No words from this episode yet. Turn on French subtitles or Live captions while you watch, then try again.';
      return;
    }
    const best = ep.quiz ? ep.quiz.best : undefined;
    ep.quiz = { items, made: Date.now(), best };
    const fresh2 = (await chrome.storage.local.get({ episodes: {} })).episodes;
    if (fresh2[key]) { fresh2[key].quiz = ep.quiz; await chrome.storage.local.set({ episodes: fresh2 }); }
  }
  start();
}

async function pickScreen() {
  show('pick');
  $('title').textContent = 'Episode quizzes';
  const { episodes } = await chrome.storage.local.get({ episodes: {} });
  const list = Object.values(episodes).sort((a, b) => b.updated - a.updated);
  $('pickEmpty').hidden = list.length > 0;
  const ul = $('epList');
  ul.textContent = '';
  list.forEach(e => {
    const li = document.createElement('li');
    const d = document.createElement('div');
    const t = document.createElement('div'); t.className = 't'; t.textContent = e.title || e.site + ' episode';
    const m = document.createElement('div'); m.className = 'm';
    m.textContent = e.site + ' · ' + (e.clicked || []).length + ' clicked · ' + Object.keys(e.seen || {}).length + ' words heard' +
      (e.quiz && typeof e.quiz.best === 'number' ? ' · best ' + e.quiz.best + '/' + e.quiz.items.length : '');
    d.append(t, m);
    const b = document.createElement('a'); b.className = 'btn primary'; b.textContent = 'Take quiz'; b.href = 'quiz.html?ep=' + encodeURIComponent(e.key);
    b.style.textDecoration = 'none';
    li.append(d, b);
    ul.append(li);
  });
}

/* ---------- wiring ---------- */
$('say').addEventListener('click', () => speak(questions[at].it.w));
$('next').addEventListener('click', () => { at++; if (at < questions.length) renderQuestion(); else finish(); });
$('retake').addEventListener('click', start);
$('fresh').addEventListener('click', () => prepare(true));
$('saveMissed').addEventListener('click', async () => {
  const { saved } = await chrome.storage.local.get({ saved: [] });
  questions.forEach((q, i) => {
    if (results[i]) return;
    if (!saved.some(s => s.word.toLowerCase() === q.it.w.toLowerCase())) saved.unshift({ word: q.it.w, gloss: q.it.gloss, line: q.it.line, at: Date.now() });
  });
  await chrome.storage.local.set({ saved });
  $('saveMissed').textContent = 'Saved to your word list';
  $('saveMissed').disabled = true;
});
document.addEventListener('keydown', e => {
  if ($('quiz').hidden || e.ctrlKey || e.metaKey || e.altKey) return;
  if (/^[1-4]$/.test(e.key) && results[at] === undefined && +e.key <= questions[at].options.length) { answer(+e.key - 1); e.preventDefault(); }
  else if (e.key === 'Enter' && !$('next').hidden && document.activeElement !== $('next')) { $('next').click(); e.preventDefault(); }
});

(async () => {
  const { episodes } = await chrome.storage.local.get({ episodes: {} });
  if (!key || !episodes[key]) { pickScreen(); return; }
  ep = episodes[key];
  const title = ep.title || ep.site + ' episode';
  $('title').textContent = title;
  document.title = 'Quiz · ' + title;
  $('kicker').textContent = ep.site + ' · Episode quiz';
  $('meta').textContent = (ep.clicked || []).length + ' words clicked · ' + Object.keys(ep.seen || {}).length + ' words heard';
  prepare(false);
})();
