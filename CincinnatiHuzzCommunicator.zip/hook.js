// Runs in the page itself. Watches the player's network traffic for subtitle files
// (ASS, WebVTT, SRT, TTML) and for playback info that lists subtitle URLs, then hands
// French subtitles to content.js. It never changes what the page receives.
(() => {
  if (window.__motamotHook) return;
  window.__motamotHook = true;

  const post = (type, data) => window.postMessage({ __motamot: true, type, data }, '*');
  const seen = new Set();
  const origFetch = window.fetch;

  function looksLikeSubs(t) {
    const head = t.slice(0, 3000);
    return /^\uFEFF?\s*(\[Script Info\]|WEBVTT)/.test(head) ||
      (/<tt[\s>]/.test(head) && /<p[\s>]/.test(t)) ||
      /^\uFEFF?\s*\d+\s*\r?\n\s*\d{1,2}:\d\d:\d\d[,.]\d{1,3}\s*-->/.test(head);
  }

  function findTracks(obj, out, keyLang, depth) {
    if (!obj || typeof obj !== 'object' || depth > 9) return out;
    if (Array.isArray(obj)) { obj.forEach(x => findTracks(x, out, keyLang, depth + 1)); return out; }
    const url = obj.url || obj.src || obj.uri;
    const fmt = String(obj.format || obj.type || '');
    if (typeof url === 'string' && (/\.(ass|ssa|vtt|srt|ttml|dfxp)(\?|$)/i.test(url) || /^(ass|ssa|vtt|webvtt|srt|ttml|dfxp)$/i.test(fmt))) {
      out.push({ url, lang: String(obj.language || obj.locale || obj.lang || keyLang || '') });
    }
    for (const k in obj) {
      const v = obj[k];
      if (v && typeof v === 'object') findTracks(v, out, /^[a-z]{2,3}(-[A-Za-z0-9]{2,4})?$/.test(k) ? k : keyLang, depth + 1);
    }
    return out;
  }

  async function fetchTrack(t) {
    if (seen.has(t.url)) return;
    seen.add(t.url);
    try {
      const r = await origFetch.call(window, t.url, { credentials: 'omit' });
      if (!r.ok) throw new Error(r.status);
      post('subtitle', { url: t.url, text: await r.text(), lang: t.lang });
    } catch (_) {
      post('fetchfail', { url: t.url, lang: t.lang });
    }
  }

  function handle(url, text, ctype) {
    if (!text || text.length < 40) return;
    if (looksLikeSubs(text)) {
      if (seen.has(url)) return;
      seen.add(url);
      post('subtitle', { url, text, lang: '' });
      return;
    }
    if ((/json/i.test(ctype) || /^\s*[{[]/.test(text)) && /subtitle|caption|timedtext/i.test(text)) {
      try {
        const tracks = findTracks(JSON.parse(text), [], '', 0);
        tracks.filter(t => /^fr/i.test(t.lang)).forEach(fetchTrack);
      } catch (_) {}
    }
  }

  const skipType = /video|audio|image|font|octet-stream|mp4|mp2t|protobuf/i;

  window.fetch = async function (...args) {
    const res = await origFetch.apply(this, args);
    try {
      const ct = res.headers.get('content-type') || '';
      const len = +(res.headers.get('content-length') || 0);
      if (!skipType.test(ct) && len < 8e6) {
        const url = res.url;
        res.clone().text().then(t => handle(url, t, ct)).catch(() => {});
      }
    } catch (_) {}
    return res;
  };

  const XO = XMLHttpRequest.prototype.open;
  const XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__mmUrl = u; return XO.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('load', () => {
      try {
        const ct = this.getResponseHeader('content-type') || '';
        if (skipType.test(ct)) return;
        const url = this.responseURL || String(this.__mmUrl || '');
        const rt = this.responseType;
        if (rt === '' || rt === 'text') handle(url, this.responseText, ct);
        else if (rt === 'json' && this.response) handle(url, JSON.stringify(this.response), 'json');
        else if (rt === 'arraybuffer' && this.response && this.response.byteLength < 8e6) {
          const t = new TextDecoder('utf-8').decode(new Uint8Array(this.response, 0, Math.min(this.response.byteLength, 3000)));
          if (looksLikeSubs(t)) handle(url, new TextDecoder('utf-8').decode(this.response), ct);
        }
      } catch (_) {}
    });
    return XS.apply(this, arguments);
  };
})();
