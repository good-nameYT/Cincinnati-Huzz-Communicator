const DEFAULTS = { enabled: true, pause: true, resume: true, hideNative: true, size: 1, liveButton: true, quiz: true };
const $ = id => document.getElementById(id);

chrome.storage.sync.get(DEFAULTS).then(s => {
  for (const k of ['enabled', 'pause', 'resume', 'hideNative', 'liveButton', 'quiz']) {
    $(k).checked = !!s[k];
    $(k).addEventListener('change', () => chrome.storage.sync.set({ [k]: $(k).checked }));
  }
  $('size').value = s.size;
  $('size').addEventListener('input', () => chrome.storage.sync.set({ size: +$('size').value }));
});

async function render() {
  const { saved } = await chrome.storage.local.get({ saved: [] });
  const ul = $('list');
  ul.textContent = '';
  $('empty').hidden = saved.length > 0;
  $('n').textContent = saved.length ? '(' + saved.length + ')' : '';
  saved.forEach((s, i) => {
    const li = document.createElement('li');
    const left = document.createElement('div');
    const w = document.createElement('div'); w.className = 'w'; w.textContent = s.word;
    left.append(w);
    if (s.gloss) { const g = document.createElement('div'); g.className = 'g'; g.textContent = s.gloss; left.append(g); }
    const rm = document.createElement('button'); rm.className = 'rm'; rm.type = 'button'; rm.textContent = '×';
    rm.setAttribute('aria-label', 'Remove ' + s.word);
    rm.addEventListener('click', async () => { saved.splice(i, 1); await chrome.storage.local.set({ saved }); render(); });
    li.append(left, rm);
    ul.append(li);
  });
}

$('copy').addEventListener('click', async () => {
  const { saved } = await chrome.storage.local.get({ saved: [] });
  if (!saved.length) { $('status').textContent = 'No saved words yet.'; return; }
  const tsv = saved.map(s => [s.word, s.gloss, s.line].map(x => (x || '').replace(/[\t\n]/g, ' ')).join('\t')).join('\n');
  try { await navigator.clipboard.writeText(tsv); $('status').textContent = 'Copied ' + saved.length + ' words (French, English, subtitle line). Pastes into Anki, Quizlet or a spreadsheet.'; }
  catch (_) { $('status').textContent = 'Copy was blocked.'; }
});

const openQuiz = k => chrome.tabs.create({ url: chrome.runtime.getURL('quiz.html' + (k ? '?ep=' + encodeURIComponent(k) : '')) });
$('allQuiz').addEventListener('click', () => openQuiz(''));

async function renderEpisodes() {
  const { episodes } = await chrome.storage.local.get({ episodes: {} });
  const list = Object.values(episodes).sort((a, b) => b.updated - a.updated).slice(0, 5);
  const ul = $('eps');
  ul.textContent = '';
  $('epsEmpty').hidden = list.length > 0;
  $('allQuiz').hidden = list.length === 0;
  list.forEach(e => {
    const li = document.createElement('li');
    const d = document.createElement('div');
    const t = document.createElement('div'); t.className = 'w'; t.textContent = e.title || e.site + ' episode';
    const m = document.createElement('div'); m.className = 'ep-m';
    m.textContent = e.site + ' · ' + (e.clicked || []).length + ' clicked' + (e.quiz && typeof e.quiz.best === 'number' ? ' · best ' + e.quiz.best + '/' + e.quiz.items.length : '');
    d.append(t, m);
    const b = document.createElement('button'); b.type = 'button'; b.className = 'go'; b.textContent = 'Quiz';
    b.addEventListener('click', () => openQuiz(e.key));
    li.append(d, b);
    ul.append(li);
  });
}

chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local') return;
  if (ch.saved) render();
  if (ch.episodes) renderEpisodes();
});
render();
renderEpisodes();
