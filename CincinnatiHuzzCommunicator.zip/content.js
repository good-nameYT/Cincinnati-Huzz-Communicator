// Draws a clickable copy of the French subtitles over the video and shows an
// English dictionary card when a word is clicked.
(() => {
  if (window.__motamotContent) return;
  window.__motamotContent = true;

  const IS_NETFLIX = /(^|\.)netflix\.com$/.test(location.hostname);
  const settings = { enabled: true, pause: true, resume: true, hideNative: true, size: 1, liveButton: true, quiz: true };
  chrome.storage.sync.get(settings).then(s => Object.assign(settings, s)).catch(() => {});
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'sync') return;
    for (const k in ch) settings[k] = ch[k].newValue;
    tick(true);
  });

  /* ================= subtitle files ================= */
  let tracks = [];          // [{url, cues}]
  let activeTrack = null;

  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || !e.data.__motamot) return;
    const { type, data } = e.data;
    if (type === 'subtitle') ingest(data.text, data.url, data.lang);
    else if (type === 'fetchfail') bgGet(data.url).then(r => { if (r && r.ok) ingest(r.text, data.url, data.lang); });
  });

  chrome.runtime.onMessage.addListener(msg => {
    if (msg && msg.type === 'track' && msg.track && Array.isArray(msg.track.cues)) {
      tracks = tracks.filter(t => t.url !== msg.track.url);
      tracks.push(msg.track);
      if (tracks.length > 6) tracks.shift();
      activeTrack = msg.track;
    }
  });

  function ingest(text, url, lang) {
    let cues = [];
    try { cues = parseAny(text); } catch (_) {}
    if (cues.length < 3) return;
    if (!/^fr/i.test(lang || '') && !looksFrench(cues)) return;
    chrome.runtime.sendMessage({ type: 'track', track: { url, cues } }).catch(() => {});
  }

  const FR_WORDS = new Set('le la les de des du un une est et je tu il elle nous vous ils elles que qui pas ne ce ça cette pour dans sur avec mais oui non mon ma mes ton ta son sa leur au aux très bien tout fait être avoir suis es sont était peut veux vais alors quoi comme'.split(' '));
  const EN_WORDS = new Set('the and you is are to of it that this what was for with not have be do my me he she we they your on in at but no yes just can will so all'.split(' '));
  function looksFrench(cues) {
    let fr = 0, en = 0;
    for (const c of cues.slice(0, 250)) {
      for (const w of c.t.toLowerCase().split(/[^\p{L}']+/u)) {
        const b = w.replace(/^(l|d|j|m|n|s|t|c|qu)'/, '');
        if (FR_WORDS.has(w) || FR_WORDS.has(b)) fr++;
        if (EN_WORDS.has(w)) en++;
      }
    }
    return fr >= 12 && fr > en * 1.5;
  }

  function parseAny(t) {
    if (/\[(Script Info|Events)\]/i.test(t.slice(0, 5000))) return parseASS(t);
    if (/<tt[\s>]/.test(t.slice(0, 3000))) return parseTTML(t);
    return parseVTT(t);
  }
  function clock(v) {
    const p = v.trim().replace(',', '.').split(':').map(Number);
    return p.reduce((a, x) => a * 60 + x, 0);
  }
  function parseASS(t) {
    const cues = []; let fmt = null, inEv = false;
    for (const l of t.split(/\r?\n/)) {
      if (/^\[Events\]/i.test(l)) { inEv = true; continue; }
      if (/^\[/.test(l)) { inEv = false; continue; }
      if (!inEv) continue;
      if (/^Format:/i.test(l)) { fmt = l.slice(7).split(',').map(x => x.trim().toLowerCase()); continue; }
      if (!fmt || !/^Dialogue:/i.test(l)) continue;
      const parts = l.slice(9).split(',');
      const n = fmt.length;
      const f = parts.slice(0, n - 1).map(x => x.trim());
      const raw = parts.slice(n - 1).join(',');
      if (/\\p[1-9]/.test(raw)) continue;
      const s = clock(f[fmt.indexOf('start')] || ''), e = clock(f[fmt.indexOf('end')] || '');
      const tx = raw.replace(/\{[^}]*\}/g, '').replace(/\\[Nn]/g, '\n').replace(/\\h/g, ' ').replace(/[ \t]+/g, ' ').trim();
      if (tx && !isNaN(s) && !isNaN(e)) cues.push({ s, e, t: tx });
    }
    return cues.sort((a, b) => a.s - b.s);
  }
  function parseVTT(t) {
    const cues = [];
    for (const b of t.replace(/\r/g, '').split(/\n{2,}/)) {
      const ls = b.split('\n');
      const i = ls.findIndex(l => l.includes('-->'));
      if (i < 0) continue;
      const m = ls[i].match(/((?:\d+:)?\d{1,2}:\d{2}[.,]\d{1,3})\s*-->\s*((?:\d+:)?\d{1,2}:\d{2}[.,]\d{1,3})/);
      if (!m) continue;
      const tx = ls.slice(i + 1).join('\n').replace(/<[^>]+>/g, '')
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').trim();
      if (tx) cues.push({ s: clock(m[1]), e: clock(m[2]), t: tx });
    }
    return cues;
  }
  function parseTTML(t) {
    const doc = new DOMParser().parseFromString(t, 'application/xml');
    if (doc.querySelector('parsererror')) return [];
    const tt = doc.documentElement;
    const tick = +(tt.getAttribute('ttp:tickRate') || 0) || 10000000;
    const fps = +(tt.getAttribute('ttp:frameRate') || 0) || 30;
    const tm = v => {
      if (!v) return NaN; let m;
      if ((m = v.match(/^([\d.]+)t$/))) return m[1] / tick;
      if ((m = v.match(/^([\d.]+)(ms|s|m|h)$/))) return m[1] * { ms: 0.001, s: 1, m: 60, h: 3600 }[m[2]];
      if ((m = v.match(/^(\d+):(\d\d):(\d\d)(?:\.(\d+))?(?::(\d+))?$/))) return +m[1] * 3600 + +m[2] * 60 + +m[3] + (m[4] ? +('0.' + m[4]) : 0) + (m[5] ? m[5] / fps : 0);
      return NaN;
    };
    const cues = [];
    for (const p of doc.getElementsByTagNameNS('*', 'p')) {
      const s = tm(p.getAttribute('begin')), e = tm(p.getAttribute('end'));
      let txt = '';
      (function walk(n) { for (const c of n.childNodes) { if (c.nodeType === 3) txt += c.nodeValue; else if (c.localName === 'br') txt += '\n'; else walk(c); } })(p);
      txt = txt.replace(/[ \t]+/g, ' ').trim();
      if (txt && !isNaN(s)) cues.push({ s, e: isNaN(e) ? s + 3 : e, t: txt });
    }
    return cues.sort((a, b) => a.s - b.s);
  }

  /* ================= current caption ================= */
  let video = null, source = '';
  function findVideo() {
    let best = null, area = 0;
    for (const v of document.querySelectorAll('video')) {
      const r = v.getBoundingClientRect();
      const a = r.width * r.height;
      if (a > area) { area = a; best = v; }
    }
    return area > 40000 ? best : null;
  }
  function currentText() {
    if (live) {
      source = 'live';
      let t = liveInterim || ((Date.now() - liveAt < 5000 || (video && video.paused)) ? liveFinal : '');
      const words = t.split(/\s+/).filter(Boolean);
      if (words.length > 16) t = '… ' + words.slice(-16).join(' ');
      return t;
    }
    if (IS_NETFLIX) {
      const nf = document.querySelector('.player-timedtext');
      const t = nf ? nf.innerText.trim() : '';
      if (t) { source = 'netflix'; return t; }
    }
    if (activeTrack && video) {
      const now = video.currentTime;
      const act = activeTrack.cues.filter(c => c.s <= now + 0.05 && now < c.e);
      if (act.length) { source = 'file'; return [...new Set(act.map(c => c.t))].join('\n'); }
      if (!IS_NETFLIX) { source = 'file'; return ''; }
    }
    if (video && video.textTracks) {
      for (const tr of video.textTracks) {
        if (tr.mode === 'disabled' || !tr.activeCues) continue;
        if (tr.language && !/^fr/i.test(tr.language)) continue;
        const parts = [...tr.activeCues].map(c => c.text || '').filter(Boolean);
        if (parts.length) { source = 'track'; return parts.join('\n').replace(/<[^>]+>/g, ''); }
      }
    }
    source = '';
    return '';
  }

  let nativeStyle = null;
  function hideNative(on) {
    if (!nativeStyle) {
      nativeStyle = document.createElement('style');
      nativeStyle.textContent = '.player-timedtext{opacity:0!important} video::cue{color:transparent!important;background:transparent!important;text-shadow:none!important}';
    }
    const want = on && settings.enabled && settings.hideNative && (source === 'netflix' || source === 'track');
    if (want && !nativeStyle.isConnected) (document.head || document.documentElement).append(nativeStyle);
    if (!want && nativeStyle.isConnected) nativeStyle.remove();
  }

  /* ================= live captions from the tab's own audio ================= */
  // Like Chrome's Live Caption: the tab's sound is shared with Chrome's speech
  // recognizer (in French), so this works even when the site has no French subtitles.
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let live = null, liveFinal = '', liveInterim = '', liveAt = 0;
  const chromeMajor = () => { const m = navigator.userAgent.match(/Chrome\/(\d+)/); return m ? +m[1] : 0; };

  async function startLive() {
    if (live) return;
    if (!SR || chromeMajor() < 135) { toast('Live captions need Chrome 135 or newer. Update Chrome from chrome://settings/help and reload this page.'); return; }
    let stream;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: { suppressLocalAudioPlayback: false },
        preferCurrentTab: true, selfBrowserSurface: 'include', surfaceSwitching: 'exclude',
        systemAudio: 'exclude', monitorTypeSurfaces: 'exclude'
      });
    } catch (e) {
      toast(e && e.name === 'NotAllowedError' ? 'Sharing was cancelled. Click Live captions to try again.' : 'Chrome could not share this tab’s audio.');
      return;
    }
    stream.getVideoTracks().forEach(t => t.stop());
    const track = stream.getAudioTracks()[0];
    if (!track) {
      stream.getTracks().forEach(t => t.stop());
      toast('No sound was shared. Click Live captions again and leave “Also share tab audio” switched on.');
      return;
    }
    const rec = new SR();
    rec.lang = 'fr-FR'; rec.continuous = true; rec.interimResults = true; rec.maxAlternatives = 1;
    live = { stream, track, rec };
    rec.onresult = e => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) liveFinal = r[0].transcript.trim();
        else interim += r[0].transcript;
      }
      liveInterim = interim.trim();
      liveAt = Date.now();
    };
    rec.onerror = e => {
      if (e.error === 'no-speech' || e.error === 'aborted') return;
      if (e.error === 'network') toast('Chrome could not reach its speech service. Check your internet connection.');
      else if (e.error === 'language-not-supported') { toast('French speech recognition is not available in this Chrome.'); stopLive(); }
      else if (/not-allowed|audio-capture/.test(e.error)) { toast('Chrome would not caption this audio (' + e.error + '). Update Chrome and try again.'); stopLive(); }
    };
    rec.onend = () => {
      if (!live || live.rec !== rec || track.readyState !== 'live') return;
      setTimeout(() => { if (live && live.rec === rec) { try { rec.start(track); } catch (_) {} } }, 250);
    };
    track.addEventListener('ended', stopLive);
    try { rec.start(track); }
    catch (_) { toast('This version of Chrome cannot caption tab audio. Update Chrome and try again.'); stopLive(); return; }
    updateLiveBtn();
    toast('Live captions on. Give it a second to catch up with the dialogue.');
  }

  function stopLive() {
    if (!live) return;
    const l = live; live = null;
    try { l.rec.abort(); } catch (_) {}
    l.stream.getTracks().forEach(t => t.stop());
    liveFinal = liveInterim = '';
    lastText = null;
    updateLiveBtn();
  }

  /* ================= episode word history (for quizzes) ================= */
  const QUIZ_SKIP = new Set(('oui non bon bien très tout tous toute toutes rien quoi comme mais donc alors avec pour dans sur sous chez sans ' +
    'par plus moins aussi encore déjà ici voilà voici hein ouais euh merci salut bonjour bonsoir allez allons ' +
    'est suis sont sommes êtes était étais étaient été être fait fais faire faites ai as avons avez ont avait avais avoir ' +
    'va vais vas vont aller peux peut pouvez veux veut voulez dit dis dire sais sait savoir vois voit voir ' +
    'cette ces cet celui celle ceux elle elles nous vous ils eux moi toi soi leur leurs notre votre nos vos ' +
    'quand comment pourquoi quel quelle quels quelles dont parce puis enfin juste vraiment peut-être toujours jamais ' +
    'non-non oui-oui monsieur madame mademoiselle').split(' '));
  const epBuf = { seen: [], clicked: [], title: '' };
  let lastSeenText = '', seenTimer = null;

  function episodeTitle() {
    if (IS_NETFLIX) {
      const t = document.querySelector('[data-uia="video-title"]');
      const s = t ? t.innerText.replace(/\s*\n+\s*/g, ' · ').trim() : '';
      if (s) return s;
    }
    return '';
  }
  function recordSeen(text) {
    if (!settings.quiz || !text || text === lastSeenText) return;
    lastSeenText = text;
    const flat = text.replace(/\n/g, ' ');
    const toks = MM.tokenize(text);
    // words that belong to a phrase (train in "en train de") are skipped
    const wordIdx = []; toks.forEach((t, i) => { if (t.word) wordIdx.push(i); });
    const inPhrase = new Set();
    MM.findBuiltin(wordIdx.map(i => toks[i].norm)).forEach(p => { for (let k = p.start; k < p.end; k++) inPhrase.add(wordIdx[k]); });
    toks.forEach((t, i) => {
      if (!t.word || inPhrase.has(i)) return;
      const w = t.norm;
      if (w.length < 3 || /'$/.test(w) || /\d/.test(w) || MM.STOP.has(w) || QUIZ_SKIP.has(w)) return;
      const before = toks.slice(0, i).map(x => x.t).join('').trim();
      const sentenceStart = !before || /[.!?…:\-–—"«»]$/.test(before);
      if (/^\p{Lu}/u.test(t.t) && !sentenceStart) return;            // probably a name
      epBuf.seen.push({ w, line: flat });
    });
  }
  function recordClick(w, gloss, line) {
    if (!settings.quiz || !w) return;
    epBuf.clicked.push({ w, gloss: gloss || '', line: line || '' });
    flushEpisode();
  }
  function flushEpisode() {
    const title = episodeTitle();
    if (title) epBuf.title = title;
    if (!epBuf.seen.length && !epBuf.clicked.length) return;
    if (!alive()) return;
    const msg = { type: 'ep', seen: epBuf.seen.splice(0), clicked: epBuf.clicked.splice(0), title: epBuf.title };
    try { chrome.runtime.sendMessage(msg).catch(() => {}); } catch (_) {}
  }
  setInterval(flushEpisode, 8000);
  window.addEventListener('pagehide', flushEpisode);

  const quizOffered = new Set();
  function maybeOfferQuiz() {
    if (!settings.quiz || !video || !quizBan) return;
    const d = video.duration;
    if (!isFinite(d) || d < 300) return;
    if (video.currentTime < d - Math.min(150, d * 0.07)) return;
    const id = location.pathname + '|' + Math.round(d);
    if (quizOffered.has(id)) return;
    quizOffered.add(id);
    flushEpisode();
    quizBan.hidden = false;
  }

  /* ================= overlay ================= */
  let host = null, shadow, wrap, caps, card, liveBtn, toastEl, toastTimer, quizBan;
  let frozen = false, lastText = '', wasPlaying = false, selEl = null, hovering = false, hoverAt = 0;

  function updateLiveBtn() {
    if (!liveBtn) return;
    liveBtn.classList.toggle('on', !!live);
    liveBtn.lastChild.textContent = live ? 'Listening · Stop' : 'Live captions';
    liveBtn.title = live ? 'Stop live captions' : 'Make French captions from this video’s audio';
  }
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.hidden = true; }, 7000);
  }

  const CSS = `
  :host{all:initial}
  .wrap{position:absolute;inset:0;pointer-events:none;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#fff}
  .caps{position:absolute;left:4%;right:4%;bottom:11%;display:flex;flex-direction:column;align-items:center;gap:.12em;text-align:center}
  .line{pointer-events:auto;background:rgba(6,7,12,.66);padding:.06em .42em .1em;border-radius:.22em;line-height:1.32;font-weight:600;
    text-shadow:0 1px 2px rgba(0,0,0,.9);max-width:100%;overflow-wrap:anywhere}
  .w{all:unset;cursor:pointer;border-radius:.16em;padding:0 .04em}
  .w:hover{background:rgba(255,216,74,.28)}
  .w:focus-visible{outline:2px solid #ffd84a}
  .w.sel{background:#ffd84a;color:#141a2f;text-shadow:none}
  .w.ph,.phgap{text-decoration:underline dotted rgba(255,216,74,.9);text-decoration-thickness:.09em;text-underline-offset:.24em}
  .w.ph.phon,.phgap.phon{background:rgba(255,216,74,.22)}
  .w.ph.sel{text-decoration:none}
  .phgap.sel{background:#ffd84a}
  .tag{display:inline-block;font:600 10px/1 ui-monospace,Menlo,Consolas,monospace;letter-spacing:.1em;text-transform:uppercase;color:#141a2f;background:#ffd84a;border-radius:4px;padding:3px 5px;margin-right:6px;vertical-align:2px}
  .canon{margin:0 0 4px;color:#9ca2bb;font-size:13px}
  .canon b{color:#eceef7;font-weight:600}
  .card{position:absolute;pointer-events:auto;width:min(390px,calc(100% - 16px));box-sizing:border-box;overflow:auto;
    background:#141826;color:#eceef7;border:1px solid #2a3044;border-radius:12px;padding:16px 16px 14px;
    box-shadow:0 18px 50px rgba(0,0,0,.55);font-size:14px;line-height:1.45;cursor:auto}
  .card[hidden]{display:none}
  .top{display:flex;align-items:center;gap:10px}
  .kicker{font:500 10px/1 ui-monospace,Menlo,Consolas,monospace;letter-spacing:.12em;text-transform:uppercase;color:#9ca2bb;margin:0;flex:1}
  .x{all:unset;cursor:pointer;color:#9ca2bb;font-size:20px;line-height:1;padding:2px 6px;border-radius:6px}
  .x:hover{color:#fff;background:#232838}
  .hwrow{display:flex;align-items:center;gap:10px;margin:6px 0 2px}
  .hw{font:400 34px/1.05 Georgia,"Times New Roman",serif;margin:0;overflow-wrap:anywhere}
  .say{all:unset;cursor:pointer;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;border:1px solid #2a3044;color:#eceef7;flex:none}
  .say:hover{border-color:#9ca2bb}
  .say svg{width:14px;height:14px}
  .gloss{font-size:17px;margin:2px 0 0}
  .gloss b{color:#ffd84a}
  .muted{color:#9ca2bb}
  .note{background:#0d1019;border-radius:8px;padding:7px 9px;color:#b9bfd4;margin:10px 0 0;font-size:13px}
  .pos{font:500 10px/1 ui-monospace,Menlo,Consolas,monospace;letter-spacing:.14em;text-transform:uppercase;color:#95a7ff;margin:14px 0 6px}
  ol{margin:0;padding-left:1.35em;display:grid;gap:4px}
  .lemma{all:unset;cursor:pointer;color:#95a7ff;font-weight:700;text-decoration:underline;text-underline-offset:2px}
  .more{all:unset;cursor:pointer;color:#9ca2bb;font-size:12px;text-decoration:underline;margin-top:4px;display:inline-block}
  .parts{margin-top:10px;display:flex;flex-wrap:wrap;gap:6px;align-items:center;color:#9ca2bb;font-size:13px}
  .chip{all:unset;cursor:pointer;border:1px solid #2a3044;border-radius:999px;padding:2px 9px;color:#eceef7}
  .ctx{margin-top:14px;padding-top:12px;border-top:1px solid #232838}
  .en{font-style:italic;color:#b9bfd4;margin:6px 0 0}
  .actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}
  .btn{all:unset;cursor:pointer;font-size:12px;font-weight:600;padding:7px 11px;border-radius:7px;border:1px solid #2a3044;color:#eceef7;text-decoration:none}
  .btn:hover{border-color:#9ca2bb}
  .btn.primary{background:#95a7ff;border-color:#95a7ff;color:#0b0d14}
  .live{all:unset;pointer-events:auto;cursor:pointer;position:absolute;top:14px;right:14px;display:inline-flex;align-items:center;gap:7px;
    font:600 12px/1 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#fff;background:rgba(6,7,12,.62);
    border:1px solid rgba(255,255,255,.22);border-radius:999px;padding:7px 12px;opacity:.5;transition:opacity .15s}
  .live:hover,.live:focus-visible,.live.on{opacity:1}
  .live:focus-visible{outline:2px solid #ffd84a}
  .live .dot{width:8px;height:8px;border-radius:50%;background:#9ca2bb}
  .live.on .dot{background:#ff5a4d;animation:mmpulse 1.2s ease-in-out infinite}
  .live[hidden]{display:none}
  @keyframes mmpulse{50%{transform:scale(1.5);opacity:.5}}
  @media (prefers-reduced-motion:reduce){.live.on .dot{animation:none}}
  .toast{position:absolute;top:54px;right:14px;max-width:min(340px,calc(100% - 28px));background:#141826;color:#eceef7;
    border:1px solid #2a3044;border-radius:10px;padding:9px 12px;font:13px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
    box-shadow:0 10px 30px rgba(0,0,0,.5)}
  .toast[hidden]{display:none}
  .quizban{position:absolute;top:14px;left:14px;pointer-events:auto;width:min(320px,calc(100% - 28px));background:#141826;color:#eceef7;
    border:1px solid #2a3044;border-left:4px solid #ffd84a;border-radius:10px;padding:12px 14px;box-shadow:0 10px 30px rgba(0,0,0,.5);
    font:13px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
  .quizban[hidden]{display:none}
  .qb-t{margin:0;font:400 20px/1.15 Georgia,"Times New Roman",serif}
  .qb-s{margin:4px 0 10px;color:#9ca2bb}
  .qb-a{display:flex;gap:6px;flex-wrap:wrap}
  `;

  function ensureHost() {
    const fs = document.fullscreenElement;
    const parent = fs && fs !== video && fs.contains(video) ? fs : document.documentElement;
    if (!host) {
      document.querySelectorAll('motamot-overlay').forEach(n => n.remove());
      host = document.createElement('motamot-overlay');
      host.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;display:block;left:0;top:0;width:0;height:0;';
      shadow = host.attachShadow({ mode: 'open' });
      shadow.innerHTML = `<style>${CSS}</style><div class="wrap"><button class="live" type="button"><span class="dot"></span><span>Live captions</span></button><div class="toast" role="status" hidden></div><div class="quizban" hidden><p class="qb-t">Your episode quiz is ready</p><p class="qb-s">10 words from this episode, starting with the ones you clicked.</p><div class="qb-a"><button class="btn primary qb-go" type="button">Take the quiz</button><button class="btn qb-no" type="button">Not now</button></div></div><div class="caps" lang="fr"></div><div class="card" hidden></div></div>`;
      wrap = shadow.querySelector('.wrap');
      caps = shadow.querySelector('.caps');
      card = shadow.querySelector('.card');
      liveBtn = shadow.querySelector('.live');
      toastEl = shadow.querySelector('.toast');
      quizBan = shadow.querySelector('.quizban');
      quizBan.querySelector('.qb-no').addEventListener('click', () => { quizBan.hidden = true; });
      quizBan.querySelector('.qb-go').addEventListener('click', () => {
        quizBan.hidden = true;
        flushEpisode();
        if (video && !video.paused) video.pause();
        try { chrome.runtime.sendMessage({ type: 'openQuiz' }).catch(() => {}); } catch (_) { retire(); }
      });
      liveBtn.addEventListener('click', () => (live ? stopLive() : startLive()));
      updateLiveBtn();
      // Hold the line still while the pointer is on it, so words don't move under the cursor.
      caps.addEventListener('mouseover', e => { if (e.target.closest('.line')) { hovering = true; hoverAt = Date.now(); } });
      caps.addEventListener('mousemove', () => { hoverAt = Date.now(); });
      // Light up the whole phrase when the pointer is on any part of it.
      caps.addEventListener('mouseover', e => {
        const t = e.target.closest('[data-ph]');
        caps.querySelectorAll('.phon').forEach(n => n.classList.remove('phon'));
        if (t) caps.querySelectorAll('[data-ph="' + t.dataset.ph + '"]').forEach(n => n.classList.add('phon'));
      });
      caps.addEventListener('mouseleave', () => caps.querySelectorAll('.phon').forEach(n => n.classList.remove('phon')));
      caps.addEventListener('mouseout', e => { if (!e.relatedTarget || !caps.contains(e.relatedTarget) || !e.relatedTarget.closest('.line')) hovering = false; });
      for (const ev of ['click', 'dblclick', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend', 'wheel', 'keydown', 'keyup', 'contextmenu']) {
        host.addEventListener(ev, e => e.stopPropagation());
      }
      caps.addEventListener('click', e => {
        let w = e.target.closest('.w');
        const gap = !w && e.target.closest('.phgap');
        if (gap) w = caps.querySelector('.w[data-ph="' + gap.dataset.ph + '"]');
        if (w) { e.preventDefault(); openCard(w); }
      });
    }
    if (host.parentNode !== parent) parent.append(host);
  }

  function place() {
    const r = video.getBoundingClientRect();
    host.style.left = r.left + 'px';
    host.style.top = r.top + 'px';
    host.style.width = r.width + 'px';
    host.style.height = r.height + 'px';
    const px = Math.max(16, Math.min(60, r.height * 0.048 * (settings.size || 1)));
    caps.style.fontSize = px + 'px';
  }

  const WORD_RE = /[\p{L}\p{M}]+(?:['’\-][\p{L}\p{M}]+)*/gu;
  const ELISION_RE = /^(l|d|j|m|n|s|t|c|qu|jusqu|lorsqu|puisqu|quoiqu)['’]/iu;
  const ELISION = {
    l: ['le', 'le / la (the)'], d: ['de', 'de (of, from, some)'], j: ['je', 'je (I)'], m: ['me', 'me (me, myself)'],
    n: ['ne', 'ne (part of a negation)'], s: ['se', 'se (oneself) or si (if)'], t: ['te', 'te (you)'], c: ['ce', 'ce (this, it)'],
    qu: ['que', 'que (that, what, than)'], jusqu: ['jusque', 'jusque (until)'], lorsqu: ['lorsque', 'lorsque (when)'],
    puisqu: ['puisque', 'puisque (since)'], quoiqu: ['quoique', 'quoique (although)']
  };
  function wordBtn(t) { const b = document.createElement('button'); b.type = 'button'; b.className = 'w'; b.textContent = t; return b; }

  /* ---------- phrases ---------- */
  const MM = globalThis.MotAMot;
  const wiktPhraseCache = new Map();   // caption text -> [{start, end, title}]
  let shownPhrases = [];               // phrases in the caption on screen
  let phraseTimer = null, pendingRender = false;

  function joinSurface(tokens, a, b) {   // tokens a..b inclusive, as they appear
    return tokens.slice(a, b + 1).map(t => t.t).join('').replace(/\s+/g, ' ').trim();
  }

  function phrasesFor(text, tokens, wordIdx) {
    const words = wordIdx.map(i => tokens[i].norm);
    const found = MM.findBuiltin(words).map(p => ({ ...p, kind: 'builtin' }));
    const used = new Array(words.length).fill(false);
    found.forEach(p => { for (let k = p.start; k < p.end; k++) used[k] = true; });
    for (const p of (wiktPhraseCache.get(text) || [])) {
      let free = true;
      for (let k = p.start; k < p.end; k++) if (used[k]) { free = false; break; }
      if (!free) continue;
      found.push({ ...p, kind: 'wikt' });
      for (let k = p.start; k < p.end; k++) used[k] = true;
    }
    return found.sort((a, b) => a.start - b.start).map(p => ({
      ...p, surface: joinSurface(tokens, wordIdx[p.start], wordIdx[p.end - 1]), words: wordIdx.slice(p.start, p.end).map(i => tokens[i].t)
    }));
  }

  // Ask Wiktionary which 2 to 4 word spans in this caption are French expressions.
  // One request per caption, only once the caption has been stable for a moment.
  function schedulePhraseCheck(text, tokens, wordIdx) {
    clearTimeout(phraseTimer);
    if (!text || wiktPhraseCache.has(text) || wordIdx.length < 2) return;
    phraseTimer = setTimeout(async () => {
      if (lastText !== text) return;
      const cands = new Map();
      for (let n = 4; n >= 2; n--) {
        for (let i = 0; i + n <= wordIdx.length; i++) {
          const a = wordIdx[i], b = wordIdx[i + n - 1];
          const between = tokens.slice(a, b + 1).filter(t => !t.word).map(t => t.t).join('');
          if (/[^\s]/.test(between)) continue;                      // crosses punctuation
          const ws = wordIdx.slice(i, i + n).map(k => tokens[k].norm);
          if (ws.every(w => MM.STOP.has(w))) continue;               // only little words
          const title = joinSurface(tokens, a, b).toLowerCase().replace(/’/g, "'");
          if (!/\s/.test(title)) continue;
          if (cands.size < 50 && !cands.has(title)) cands.set(title, { start: i, end: i + n });
        }
      }
      if (!cands.size) { wiktPhraseCache.set(text, []); return; }
      const url = 'https://en.wiktionary.org/w/api.php?action=query&format=json&formatversion=2&origin=*&redirects=1' +
        '&prop=categories&cllimit=max&clcategories=' + encodeURIComponent('Category:French lemmas|Category:French multiword terms|Category:French non-lemma forms') +
        '&titles=' + encodeURIComponent([...cands.keys()].join('|'));
      const r = await bgGet(url);
      if (!r || !r.ok) return;
      let spans = [];
      try {
        const q = JSON.parse(r.text).query || {};
        const map = new Map();
        (q.normalized || []).forEach(x => map.set(x.from, x.to));
        const redir = new Map((q.redirects || []).map(x => [x.from, x.to]));
        const good = new Set((q.pages || []).filter(p => !p.missing && p.categories && p.categories.length).map(p => p.title));
        for (const [title, span] of cands) {
          let t = map.get(title) || title;
          t = redir.get(t) || t;
          if (good.has(t)) spans.push({ ...span, title: t });
        }
        // keep the longest, non overlapping
        spans.sort((a, b) => (b.end - b.start) - (a.end - a.start) || a.start - b.start);
        const used = [];
        spans = spans.filter(s => { for (let k = s.start; k < s.end; k++) if (used[k]) return false; for (let k = s.start; k < s.end; k++) used[k] = true; return true; });
      } catch (_) { return; }
      wiktPhraseCache.set(text, spans);
      if (wiktPhraseCache.size > 400) wiktPhraseCache.delete(wiktPhraseCache.keys().next().value);
      if (spans.length && lastText === text) pendingRender = true;
    }, 450);
  }

  function renderCaption(text) {
    caps.textContent = '';
    shownPhrases = [];
    pendingRender = false;
    if (!text) return;
    const tokens = MM.tokenize(text);
    const wordIdx = [];
    tokens.forEach((t, i) => { if (t.word) wordIdx.push(i); });
    shownPhrases = phrasesFor(text, tokens, wordIdx);
    const phOfWord = new Map();               // token index -> phrase index
    shownPhrases.forEach((p, pi) => { for (let k = p.start; k < p.end; k++) phOfWord.set(wordIdx[k], pi); });

    const flat = text.replace(/\n/g, ' ');
    let div = null;
    const newLine = () => { div = document.createElement('div'); div.className = 'line'; div.dataset.text = flat; caps.append(div); };
    newLine();
    tokens.forEach((t, i) => {
      if (t.word) {
        const b = wordBtn(t.t);
        if (phOfWord.has(i)) { b.classList.add('ph'); b.dataset.ph = phOfWord.get(i); }
        div.append(b);
        return;
      }
      const parts = t.t.split('\n');
      parts.forEach((part, j) => {
        if (j > 0) newLine();
        if (!part) return;
        const prevPh = phOfWord.get(i - 1), nextPh = phOfWord.get(i + 1);
        if (j === 0 && parts.length === 1 && prevPh !== undefined && prevPh === nextPh) {
          const g = document.createElement('span'); g.className = 'phgap'; g.dataset.ph = prevPh; g.textContent = part; div.append(g);
        } else div.append(part);
      });
    });
    [...caps.querySelectorAll('.line')].forEach(d => { if (!d.textContent.trim()) d.remove(); });
    schedulePhraseCheck(text, tokens, wordIdx);
    clearTimeout(seenTimer);
    seenTimer = setTimeout(() => { if (lastText === text) recordSeen(text); }, 900);
  }

  function tick(force) {
    const v = findVideo();
    if (v !== video) {
      if (video) video.removeEventListener('play', onPlay);
      video = v;
      if (video) video.addEventListener('play', onPlay);
      lastText = null;
    }
    if (!video || !settings.enabled) {
      if (host) host.style.display = 'none';
      hideNative(false);
      if (frozen) closeCard(false);
      if (!settings.enabled) stopLive();
      return;
    }
    ensureHost();
    host.style.display = 'block';
    liveBtn.hidden = !settings.liveButton && !live;
    place();
    maybeOfferQuiz();
    if (frozen) return;
    if (hovering && source === 'live' && Date.now() - hoverAt < 2500) return;
    const text = currentText();
    if (text !== lastText || force || (pendingRender && !hovering)) { lastText = text; renderCaption(text); }
    hideNative(true);
  }
  const tickTimer = setInterval(() => { if (!alive()) { retire(); return; } tick(); }, 150);
  document.addEventListener('fullscreenchange', () => setTimeout(() => tick(true), 50));

  function onPlay() { if (frozen) { wasPlaying = false; closeCard(false); } }
  document.addEventListener('keydown', e => { if (frozen && e.key === 'Escape') closeCard(true); }, true);

  /* ================= dictionary ================= */
  // True while this script is still connected to the extension. After the extension is
  // reloaded or reinstalled, scripts left running in open tabs lose that connection.
  function alive() { try { return !!(chrome.runtime && chrome.runtime.id); } catch (_) { return false; } }

  function bgGet(url) {
    if (!alive()) { retire(); return Promise.resolve({ ok: false, status: 0, dead: true }); }
    let send;
    try { send = chrome.runtime.sendMessage({ type: 'get', url }); }
    catch (_) { retire(); return Promise.resolve({ ok: false, status: 0, dead: true }); }
    const timeout = new Promise(res => setTimeout(() => res({ ok: false, status: 0, timeout: true }), 10000));
    return Promise.race([Promise.resolve(send).then(r => r || { ok: false, status: 0 }).catch(() => ({ ok: false, status: 0 })), timeout]);
  }

  let retired = false;
  function retire() {
    if (retired) return;
    retired = true;
    clearInterval(tickTimer);
    try { stopLive(); } catch (_) {}
    if (card) { card.hidden = true; }
    if (caps) caps.textContent = '';
    if (nativeStyle && nativeStyle.isConnected) nativeStyle.remove();
    toast('Cincinnati Huzz Communicator was updated. Refresh this page to keep using it.');
    setTimeout(() => { if (host) host.remove(); }, 9000);
  }
  const cache = new Map();
  const decode = s => new DOMParser().parseFromString(s, 'text/html').documentElement.textContent;

  async function translate(text) {
    const key = 'tr:' + text;
    if (cache.has(key)) return cache.get(key);
    const r = await bgGet('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(text.slice(0, 480)) + '&langpair=fr|en');
    if (!r || !r.ok) return null;
    try {
      let t = JSON.parse(r.text).responseData.translatedText;
      if (!t || /MYMEMORY WARNING|INVALID|QUERY LENGTH/i.test(t)) return null;
      t = decode(t);
      cache.set(key, t);
      return t;
    } catch (_) { return null; }
  }

  function htmlToSegs(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const segs = [];
    (function walk(n) {
      for (const c of n.childNodes) {
        if (c.nodeType === 3) segs.push({ t: c.textContent });
        else if (c.nodeType === 1) {
          if (['UL', 'OL', 'DL', 'STYLE', 'SCRIPT', 'SUP', 'LINK'].includes(c.tagName)) continue;
          if (c.tagName === 'A') {
            const m = (c.getAttribute('href') || '').match(/^\/wiki\/([^#?]+)#French/);
            if (m) { segs.push({ t: c.textContent, link: decodeURIComponent(m[1]).replace(/_/g, ' ') }); continue; }
          }
          walk(c);
        }
      }
    })(doc.body);
    return segs;
  }
  async function wiktRest(w) {
    const r = await bgGet('https://en.wiktionary.org/api/rest_v1/page/definition/' + encodeURIComponent(w.replace(/ /g, '_')) + '?redirect=true');
    if (r.status === 404) return { missing: true };
    if (!r.ok) throw new Error('rest');
    const fr = (JSON.parse(r.text).fr) || [];
    const senses = fr.map(p => ({
      pos: p.partOfSpeech,
      defs: (p.definitions || []).map(d => htmlToSegs(d.definition || '')).filter(s => s.some(x => x.t.trim()))
    })).filter(p => p.defs.length);
    return senses.length ? { senses } : { missing: true };
  }

  const POS_RE = /^(Noun|Verb|Adjective|Adverb|Pronoun|Preposition|Conjunction|Interjection|Article|Determiner|Numeral|Participle|Phrase|Prepositional phrase|Proper noun|Contraction|Particle|Prefix|Suffix|Idiom)$/;
  const FORM_TPL = /^(inflection of|infl of|plural of|feminine of|feminine plural of|masculine plural of|form of|alternative form of|alt form|alt sp|past participle of|fr-past participle of|present participle of|abbreviation of|synonym of|syn of|elision of|contraction of|apocopic form of)$/i;
  function cleanWikitext(s) {
    s = s.replace(/<ref[^>]*\/>/g, '').replace(/<ref[\s\S]*?<\/ref>/g, '').replace(/<[^>]+>/g, '');
    s = s.replace(/\[\[(?:[^\]|]*\|)?([^\]]*)\]\]/g, '$1');
    for (let i = 0; i < 12 && /\{\{[^{}]*\}\}/.test(s); i++) {
      s = s.replace(/\{\{([^{}]*)\}\}/g, (_, inner) => {
        const parts = inner.split('|').map(x => x.trim());
        const name = parts.shift().toLowerCase();
        const pos = parts.filter(p => !/^[\w-]+=/.test(p));
        if (FORM_TPL.test(name)) {
          const label = /^(inflection of|infl of)$/.test(name) ? 'form of' : name.replace(/^fr-/, '');
          return pos[1] ? label + ' \u0001' + pos[1] + '\u0002' : '';
        }
        if (['lb', 'lbl', 'label', 'tlb'].includes(name)) { const l = pos.slice(1).filter(p => p && p !== '_' && p !== 'and' && p !== 'or'); return l.length ? '(' + l.join(', ') + ')' : ''; }
        if (['l', 'm', 'll', 'link', 'mention', 'l-self'].includes(name)) return pos[2] || pos[1] || '';
        if (['w', 'wp'].includes(name)) return pos[1] || pos[0] || '';
        if (['gloss', 'gl', 'q', 'qual', 'qualifier', 'i', 'qf', 'sense'].includes(name)) return pos.length ? '(' + pos.join(', ') + ')' : '';
        if (['non-gloss definition', 'n-g', 'ng'].includes(name)) return pos[0] || '';
        return '';
      });
    }
    s = s.replace(/'''?/g, '').replace(/\s+/g, ' ').replace(/^[\s,;:]+/, '').trim();
    const segs = [];
    s.split(/(\u0001[^\u0002]*\u0002)/).forEach(part => {
      if (!part) return;
      if (part[0] === '\u0001') { const w = part.slice(1, -1); segs.push({ t: w, link: w }); }
      else segs.push({ t: part });
    });
    return segs;
  }
  async function wiktWikitext(w) {
    const r = await bgGet('https://en.wiktionary.org/w/api.php?action=parse&page=' + encodeURIComponent(w) + '&prop=wikitext&format=json&formatversion=2&redirects=1&origin=*');
    if (!r.ok) throw new Error('api');
    const j = JSON.parse(r.text);
    const t = j && j.parse && j.parse.wikitext;
    if (!t) return { missing: true };
    const i = t.search(/^==\s*French\s*==\s*$/m);
    if (i < 0) return { missing: true };
    const rest = t.slice(i + 2);
    const end = rest.search(/\n==[^=]/);
    const sec = end < 0 ? rest : rest.slice(0, end);
    const out = []; let cur = null;
    for (const line of sec.split('\n')) {
      const h = line.match(/^=+\s*(.+?)\s*=+\s*$/);
      if (h) { cur = POS_RE.test(h[1]) ? { pos: h[1], defs: [] } : null; if (cur) out.push(cur); continue; }
      if (cur && /^#\s/.test(line)) { const d = cleanWikitext(line.slice(2)); if (d.some(x => x.t.trim())) cur.defs.push(d); }
    }
    const senses = out.filter(p => p.defs.length);
    return senses.length ? { senses } : { missing: true };
  }
  async function wikt(w) {
    try { return await wiktInner(w); } catch (_) { return { error: true }; }
  }
  async function wiktInner(w) {
    const key = 'wk:' + w;
    if (cache.has(key)) return cache.get(key);
    let res;
    try { res = await wiktRest(w); }
    catch (_) { try { res = await wiktWikitext(w); } catch (__) { res = { error: true }; } }
    if (res.missing) { try { const alt = await wiktWikitext(w); if (alt.senses) res = alt; } catch (_) {} }
    if (!res.error) cache.set(key, res);
    return res;
  }

  /* ================= card ================= */
  let reqId = 0;
  function el(tag, cls, text) { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }

  function openCard(wordEl) {
    if (!frozen && video) {
      wasPlaying = !video.paused;
      if (settings.pause && wasPlaying) video.pause();
    }
    frozen = true;
    caps.querySelectorAll('.sel').forEach(n => n.classList.remove('sel'));
    selEl = wordEl;
    const context = wordEl.closest('.line').dataset.text;
    const ph = wordEl.dataset.ph != null ? shownPhrases[+wordEl.dataset.ph] : null;
    if (ph) {
      caps.querySelectorAll('[data-ph="' + wordEl.dataset.ph + '"]').forEach(n => n.classList.add('sel'));
      showPhrase(ph, context, wordEl.textContent);
    } else {
      wordEl.classList.add('sel');
      showWord(wordEl.textContent, context);
    }
  }

  function closeCard(resume) {
    frozen = false;
    reqId++;
    if (card) { card.hidden = true; card.textContent = ''; }
    if (caps) caps.querySelectorAll('.sel').forEach(n => n.classList.remove('sel'));
    selEl = null;
    if (resume && wasPlaying && settings.resume && video && video.paused) video.play().catch(() => {});
    wasPlaying = false;
    lastText = null;
  }

  function positionCard() {
    if (!selEl) return;
    const wr = wrap.getBoundingClientRect();
    const cr = caps.getBoundingClientRect();
    const sr = selEl.getBoundingClientRect();
    const avail = Math.max(160, cr.top - wr.top - 12);
    card.style.maxHeight = avail + 'px';
    card.style.bottom = (wr.bottom - cr.top + 10) + 'px';
    const w = card.offsetWidth;
    const center = sr.left + sr.width / 2 - wr.left;
    card.style.left = Math.max(8, Math.min(wr.width - w - 8, center - w / 2)) + 'px';
  }

  function speak(text) {
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'fr-FR'; u.rate = 0.9;
    const v = speechSynthesis.getVoices().find(v => /^fr/i.test(v.lang));
    if (v) u.voice = v;
    speechSynthesis.speak(u);
  }

  const SPEAKER = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>';

  // Shared card frame: header, headword, gloss slot, body slot, line translation and links.
  function cardFrame({ kicker, head, speakText, lookup, saveWord, context, id }) {
    card.textContent = '';
    card.hidden = false;
    const top = el('div', 'top');
    top.append(el('p', 'kicker', kicker));
    const x = el('button', 'x', '×'); x.type = 'button'; x.title = 'Close (Esc)'; x.setAttribute('aria-label', 'Close');
    x.addEventListener('click', () => closeCard(true));
    top.append(x);
    card.append(top);

    const row = el('div', 'hwrow');
    row.append(el('p', 'hw', head));
    const say = el('button', 'say'); say.type = 'button'; say.title = 'Hear it'; say.setAttribute('aria-label', 'Hear ' + speakText);
    say.innerHTML = SPEAKER;
    say.addEventListener('click', () => speak(speakText));
    row.append(say);
    card.append(row);

    const extra = el('div');
    const gloss = el('p', 'gloss muted', 'Translating…');
    const body = el('div');
    body.append(el('p', 'muted', 'Looking up definitions…'));
    card.append(extra, gloss, body);

    const after = el('div');
    card.append(after);

    const ctx = el('div', 'ctx');
    const en = el('p', 'en');
    const actions = el('div', 'actions');
    const save = el('button', 'btn primary', 'Save'); save.type = 'button';
    const tl = el('button', 'btn', 'Translate line'); tl.type = 'button';
    const lk = lookup.toLowerCase();
    const wk = el('a', 'btn', 'Wiktionary'); wk.href = 'https://en.wiktionary.org/wiki/' + encodeURIComponent(lk.replace(/ /g, '_')) + '#French'; wk.target = '_blank'; wk.rel = 'noopener';
    const wr = el('a', 'btn', 'WordReference'); wr.href = 'https://www.wordreference.com/fren/' + encodeURIComponent(lk); wr.target = '_blank'; wr.rel = 'noopener';
    actions.append(save, tl, wk, wr);
    ctx.append(en, actions);
    card.append(ctx);

    const state = { glossText: '' };
    const key = saveWord.toLowerCase();
    chrome.storage.local.get({ saved: [] }).then(({ saved }) => { if (saved.some(s => s.word.toLowerCase() === key)) save.textContent = 'Saved'; });
    save.addEventListener('click', async () => {
      const { saved } = await chrome.storage.local.get({ saved: [] });
      if (!saved.some(s => s.word.toLowerCase() === key)) {
        saved.unshift({ word: saveWord, gloss: state.glossText, line: context || '', site: location.hostname.replace(/^www\./, ''), at: Date.now() });
        await chrome.storage.local.set({ saved });
      }
      save.textContent = 'Saved';
    });
    tl.addEventListener('click', async () => {
      tl.remove();
      en.textContent = 'Translating line…';
      const t = await translate(context || '').catch(() => null);
      if (id === reqId) { en.textContent = t ? '“' + t + '”' : 'Line translation unavailable right now.'; positionCard(); }
    });
    requestAnimationFrame(positionCard);
    return { extra, gloss, body, after, state };
  }

  function setGloss(gloss, t, fallback) {
    gloss.textContent = '';
    gloss.classList.toggle('muted', !t);
    if (t) { gloss.append('≈ '); gloss.append(el('b', null, t)); }
    else gloss.textContent = fallback;
  }

  function renderSenses(body, res, selfWord, context, word) {
    body.textContent = '';
    if (res.error) { body.append(el('p', 'note', 'Could not reach Wiktionary. Check your connection and click again.')); return; }
    if (!res.senses) { body.append(el('p', 'note', 'No French entry for "' + word + '" on Wiktionary. It may be a name or slang. Try WordReference.')); return; }
    res.senses.forEach(p => {
      body.append(el('p', 'pos', p.pos));
      const ol = el('ol');
      p.defs.forEach((segs, i) => {
        const li = el('li');
        segs.forEach(s => {
          if (s.link && s.link.toLowerCase() !== selfWord) {
            const b = el('button', 'lemma', s.t); b.type = 'button'; b.title = 'Look up ' + s.link;
            b.addEventListener('click', () => showWord(s.link, context));
            li.append(b);
          } else li.append(s.t);
        });
        if (i >= 3) li.hidden = true;
        ol.append(li);
      });
      body.append(ol);
      if (p.defs.length > 3) {
        const m = el('button', 'more', 'Show ' + (p.defs.length - 3) + ' more'); m.type = 'button';
        m.addEventListener('click', () => { ol.querySelectorAll('li[hidden]').forEach(li => { li.hidden = false; }); m.remove(); positionCard(); });
        body.append(m);
      }
    });
  }

  async function showWord(raw, context) {
    const id = ++reqId;
    const display = raw.replace(/’/g, "'");
    const em = display.match(/^(l|d|j|m|n|s|t|c|qu|jusqu|lorsqu|puisqu|quoiqu)'$/i);
    const elision = em ? ELISION[em[1].toLowerCase()] : null;
    const word = elision ? elision[0] : display;
    const lower = word.toLowerCase();

    const f = cardFrame({ kicker: 'FR → EN', head: display, speakText: word, lookup: word, saveWord: word, context, id });
    if (elision) f.extra.append(el('p', 'note', display + ' is short for ' + elision[1] + ', used before a vowel or silent h.'));
    if (/-/.test(word)) {
      const parts = el('div', 'parts'); parts.append('Look up each part:');
      word.split('-').filter(Boolean).forEach(p => { const c = el('button', 'chip', p); c.type = 'button'; c.addEventListener('click', () => showWord(p, context)); parts.append(c); });
      f.after.append(parts);
    }

    translate(lower).catch(() => null).then(t => {
      if (id !== reqId) return;
      f.state.glossText = t || '';
      setGloss(f.gloss, t, 'No quick translation right now. See the definitions below or try WordReference.');
      recordClick(word, t || '', context);
    });

    let res = await wikt(lower);
    if (res.missing && word !== lower) res = await wikt(word);
    if (id !== reqId) return;
    renderSenses(f.body, res, lower, context, word);
    positionCard();
  }

  async function showPhrase(ph, context, clicked) {
    const id = ++reqId;
    const builtin = ph.kind === 'builtin' ? ph.entry : null;
    const canon = builtin ? builtin.canon : ph.title;
    const f = cardFrame({ kicker: 'Expression · FR → EN', head: ph.surface, speakText: ph.surface, lookup: canon, saveWord: canon, context, id });

    if (canon.toLowerCase() !== ph.surface.toLowerCase().replace(/’/g, "'")) {
      const c = el('p', 'canon'); c.append('Dictionary form: '); c.append(el('b', null, canon)); f.extra.append(c);
    }
    if (builtin) {
      f.state.glossText = builtin.gloss;
      f.gloss.textContent = '';
      f.gloss.classList.remove('muted');
      f.gloss.append(el('span', 'tag', 'Phrase'));
      f.gloss.append(el('b', null, builtin.gloss));
      recordClick(canon, builtin.gloss, context);
      if (builtin.note) f.gloss.after(el('p', 'note', builtin.note));
    } else {
      translate(ph.surface).catch(() => null).then(t => {
        if (id !== reqId) return;
        f.state.glossText = t || '';
        setGloss(f.gloss, t, 'See the definitions below.');
        recordClick(canon, t || '', context);
      });
    }

    const parts = el('div', 'parts'); parts.append('Just one word:');
    ph.words.forEach(w => {
      const c = el('button', 'chip', w); c.type = 'button';
      if (w === clicked) c.style.borderColor = '#ffd84a';
      c.addEventListener('click', () => {
        caps.querySelectorAll('.sel').forEach(n => n.classList.remove('sel'));
        if (selEl) selEl.classList.add('sel');
        showWord(w, context);
      });
      parts.append(c);
    });
    f.after.append(parts);

    // Dictionary entry for the expression; for "être en train de" also try "en train de".
    const tries = [canon.toLowerCase()];
    const stripped = canon.replace(/^(être|avoir|faire|aller|venir|se|s')\s?/i, '').trim().toLowerCase();
    if (stripped && stripped !== tries[0] && /\s/.test(stripped)) tries.push(stripped);
    let res = { missing: true };
    for (const t of tries) { res = await wikt(t); if (res.senses || res.error) break; }
    if (id !== reqId) return;
    if (!res.senses && builtin) f.body.textContent = '';
    else renderSenses(f.body, res, canon.toLowerCase(), context, canon);
    positionCard();
  }
})();
